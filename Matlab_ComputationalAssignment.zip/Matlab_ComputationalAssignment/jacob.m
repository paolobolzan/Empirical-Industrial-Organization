function f=jacob(theta,delta,data)

% jacob
% Jacobian of the implicit function that defines the mean utility
% This function is needed to compute the optimal instruments at a given
% value of theta
% 
% Written by Mathias Reynaert (2013)
% Original Source: Aviv Nevo (2000)


if data.drawsintegration~=1
%% Unpack
nodes=data.nodes;
xv=data.xv;
nrc=data.nrc;
cdid=data.cdid;
qweight=data.qweight;

%% Market Shares
[~, sij, wsij]=ShareCalculation(theta,delta,data);

%% Jacobian
derTheta=zeros(size(xv,1),size(theta,1));
for l = 1:max(cdid)
wssij=wsij((cdid==l),:);
ssij=sij((cdid==l),:);
sqweight=qweight((cdid==l),:);
part1=wssij*ssij';
derShareDelt = (diag(sum(wssij,2)) - part1);
f1 = zeros(size(derShareDelt,1),nrc);
% computing (partial share)/(partial sigma)
for i = 1:nrc   
 	sxv=xv(cdid==l,((i-1)*nodes)+1:i*nodes);
    sumxv=sum(sxv.*ssij,1);
    sumxv=repmat(sumxv,size(sxv,1),1);
 	f1(:,i) = sum(sqweight.*(ssij.*(sxv-sumxv)),2);
 	clear sxv sumxv
end
derTheta((cdid==l),:)=-derShareDelt\f1;
end
f=derTheta;

else
% Unpack
ndraws=data.ndraws;
xv=data.xv;
nrc=data.nrc;
cdid=data.cdid;
j = data.j;

% Market Shares
[~, sij,~]=ShareCalculation(theta,delta,data);

% Jacobian
derTheta=zeros(size(xv,1),size(theta,1));
for l = 1:max(cdid)
    ssij=sij((cdid==l),:); 
    part1=(ssij*ssij'); 
    derShareDelt = (diag(sum(ssij,2)) - part1)/ndraws;

    f1 = zeros(size(derShareDelt,1),nrc*(1+j));
    % computing (partial share)/(partial sigma)
     for i = 1:nrc
         for k = 1:1+j
             sxv=xv(cdid==l,((i-1)*(1+j)*ndraws)+(k-1)*ndraws+1:((i-1)*(1+j)*ndraws)+k*ndraws); 
             sumxv=sum(sxv.*ssij,1); % column sum gives a row vector
             sumxv=repmat(sumxv,size(sxv,1),1); % repeat the row vector over rows
             f1(:,(i-1)*(1+j)+k) = mean((ssij.*(sxv-sumxv)),2); % row sum over the random draws gives a column
             clear sxv sumxv
         end
     end
    derTheta((cdid==l),:)=-derShareDelt\f1; % CQ: derShareDelt is the Omega in the paper. this jacobian is defined with region clustered standard error
end
f=derTheta;    
end 
end