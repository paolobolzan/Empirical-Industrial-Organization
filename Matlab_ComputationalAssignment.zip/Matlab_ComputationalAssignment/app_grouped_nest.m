clear
clear global
clc

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                    ')

delete mydiary_app.txt %we don't want any old mydiary.txt file to interfere.
diary mydiary_app.txt
date = datestr(clock)

global invA ns x1 x2 s_jt IV vfull dfull theta1 theti thetj cdid cdindex v demogr mtol
%set tolerance inside the contraction mapping
mtol = 5e-16;

data_app; %do-file that imports dataset "dataset_computational_noise.csv"
data_geographics; %do-file that imports dataset "demogr_apps.csv"

%delete unnecessary variables
datapp(:,{'app','app_id','ndownloads','lowerbound','upperbound','appgenre','ndgenre','inapppurchases','estimateddownloads','highest_rank','lowest_rank'})=[];

datapp(isnan(datapp.averagescore),:)=[];

%create a variable identifying country and year
datapp.countryyear=strcat(cellstr(datapp.country), '_', num2str(datapp.year));
datapp.countryyearnest=strcat(cellstr(datapp.countryyear), '_', cellstr(datapp.nest));

vec=1:1:size(datapp,1);
datapp.id=vec';
datapp.countryyearnest=strcat(cellstr(datapp.countryyear), '_', cellstr(datapp.nest));

sumarray = grpstats(datapp.new_est, datapp.countryyearnest, @sum);
groupindices = grp2idx(datapp.countryyearnest);
datapp.downloads_grouped = sumarray(groupindices);

datapp.countryyearnest=categorical(datapp.countryyearnest);
[C,ia,ic] = unique(datapp.countryyearnest);
datapp=datapp(ia,:);

%sort table according to country, year & nest
datapp=sortrows(datapp,'countryyearnest');

%calculate the marketshare of each country(market) in each year
sumarray = grpstats(datapp.downloads_grouped, datapp.countryyear, @sum);
groupindices = grp2idx(datapp.countryyear);
datapp.DownloadsCountryYear = sumarray(groupindices);

%calculate the marketshare of each app in each country(market) in each year
datapp.mktshare=datapp.downloads_grouped./datapp.DownloadsCountryYear;

%calculate the marketshare of each nest in each country(market) in
%each year
sumarray = grpstats(datapp.mktshare, datapp.countryyearnest, @sum);
groupindices = grp2idx(datapp.countryyearnest);
datapp.MktShareCountryYearNest = sumarray(groupindices);

%set the values not in the outside good to 0
%index=~ismember(datapp.nest,'OUTSIDE')
%datapp.MktShareCountryYearNest(index)=0

%create a column of number of apps per each nest per country per year
datapp.count=ones(size(datapp,1),1); %create a columns of ones
sumarray = grpstats(datapp.count, datapp.countryyearnest, @sum);
groupindices = grp2idx(datapp.countryyearnest);
datapp.CountCountryYearNest = sumarray(groupindices);

%create a table of all outside marketshares
index=ismember(datapp.nest,'OUTSIDE');
outside=datapp.MktShareCountryYearNest(index);
osmark=datapp.countryyearnest(index);
outside=table(outside,osmark);
outside=unique(outside);
outside=sortrows(outside,'osmark');

ns=500
demogr=table2array(demograpps);
demogr(:,1:ns)=demogr(:,1:ns)/1000;

% The  vector  below relates each observation to the market it is in &
% creates a vector outsideshare that is equal to the corresponding
% outsideshare for each country and year
id_demo=unique(datapp.countryyear);

cdid=[];
outid=[];
cdid_demogr=[];
cdindex=0;
for i=1:length(id_demo)
   if i==1
    napp_market_year=sum(strcmp(datapp.countryyear, id_demo(i)));
    cdid=[cdid ; i*ones(napp_market_year,1)];
    cdindex=[1 ; cdindex(end)+napp_market_year];
    vec=zeros(napp_market_year,1);
    vec(:,:)=outside{i,1};
    datapp.outsideshare(1:cdindex(end))=vec(:,:);
    clear vec
   else
    napp_market_year=sum(strcmp(datapp.countryyear, id_demo(i)));
    cdid=[cdid ; i*ones(napp_market_year,1)];
    cdindex=[cdindex ; cdindex(end)+napp_market_year];
    vec=zeros(napp_market_year,1);
    vec(:,:)=outside{i,1};
    datapp.outsideshare(cdindex(end-1)+1:cdindex(end))=vec(:,:);
    clear vec
   end
end
cdindex(1)=[];

disp(['Object cdid dimensions: ' num2str(size(cdid)) ])

% the vector below provides for each index the of the last observation   in the data  

disp(['The dimensions of object cdindex are      ' num2str(size(cdindex)) ])


%create dummy vars for country and append them to the table
countries=dummyvar(datapp.country); %create dummy vars for the countries
country_names=unique(datapp.country); %extract unique country names
datapp=[datapp array2table(countries)]; %add dummy cars to the data table
datapp.Properties.VariableNames(20:end) = string(country_names); %rename dummy vars according to country name

%create dummy vars for year and append them to the table
datapp.year=categorical(datapp.year);
years=dummyvar(datapp.year);
years_number=unique(datapp.year);
datapp=[datapp array2table(years)];
datapp.Properties.VariableNames(32:end) = string(years_number);

%scaling=100;
%dataa=datapp;
%dataa{:,:}=datapp./scaling;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%original setup: 

%characteristics of the products are price, average score, in app purchases
x1=[ones(size(datapp,1),1) table2array(datapp(:,{'price', 'averagescore', 'iap'}))];

%only price income is 
x2=[datapp.price];

IV = [datapp.CountCountryYearNest];

s_jt=datapp.mktshare;
s_0=datapp.outsideshare;

theta2w=[1 -1 1]; 
%First elemnet is the guess for the estimate of the constant; 
%Second element is the guess of the intercation between the element of X2 and the first demographic;
%Third element is the guess of the estimate of the interaction of the first element of X2 with the second element of the demogrtaphics


disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                    ')

% starting values. zero elements in the following matrix correspond to
% coeff that will not be max over,i.e are fixed at zero.  The defaults are in %comments here

disp('                                                                    ')
disp(['The dimensions of object theta2w are      ' num2str(size(theta2w)) ])
disp('                                                                    ')

% create a vector of the non-zero elements in the above matrix, and the
% corresponding row and column indices. this facilitates passing values %
% to the functions below. %

[theti, thetj, theta2]=find(theta2w);

load random_demographics_medicare
v=v(1:36,:);

%nmkt = size(demogr,1);     % number of markets = (# of years)*(# of regionid)  %
nmkt = length(id_demo);
demogr=table2array(demograpps);
cdid_demogr=cdid;
vfull = v(cdid_demogr,:);
dfull = demogr(cdid_demogr,:);

%create instruments based on demographics
demogr_income=demogr(cdid_demogr,1);
demogr_diffall=demogr(cdid_demogr,ns+1);

IV=[IV IV(:,1).*demogr_income IV(:,1).*demogr_diffall];
  
disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                   ')

n_inst = size(IV,2);   %Number of instruments for price

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                    ')

disp(['The dimensions of object IV are ' num2str(size(IV)) ])

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                    ')

% create weight matrix
invA = inv(IV'*IV);
mid2 = x1'*IV*invA*IV'*x1;
inv(mid2);

disp(['The dimensions of object invA  are ' num2str(size(invA)) ])

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                   ')

% Logit results and save the mean utility as initial values for the
%search below.


y = log(s_jt) - log(s_0);

mid = x1'*IV*invA*IV';
t = (mid*x1)\(mid*y);
mvalold = x1*t;
oldt2 = zeros(size(theta2));
mvalold = exp(mvalold);

 %s_jt and outshr and x1 are  data that Nevo provides

disp(['Object y dimensions: ' num2str(size(y)) ])
disp(['Object mid dimensions: ' num2str(size(mid)) ])
disp(['Object t dimensions: ' num2str(size(t)) ])
disp(['Object mvalold dimensions: ' num2str(size(mvalold)) ])
disp(['Object oldt2 dimensions: ' num2str(size(oldt2)) ])

%the next command creates a new file, mvalold.mat, with mvaoldold and oldt2 in it, and then clears out the old mvalold from memory. 

save mvalold mvalold oldt2
clear mid y outshr t oldt2 mvalold temp sum1

% the matrix v has 80 iid normal random numbers for each of the 94 observations
% the matrix demogr has random draws from the CPS for 20 individuals per obs.

disp(['Object vfull dimensions: ' num2str(size(vfull)) ])
disp(['Object dfull dimensions: ' num2str(size(dfull)) ])

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                   ')

%Below,   set the maximum number of iterations for the main optimization command. Note .that the number of iterations for the meanval.m calculation is separate, and unconstrained. 

options = optimset('GradObj','off','MaxIter',150,'Display','iter','TolFun',0.01,'TolX',0.01);
tic

%gmmobjg.m  is a  separate matlab file created by Bronwyn Hall to %replace  Nevo's gmmobj.m and gradobj.m with one file for Matlab 6 or 7.
%gmmobjg calls up meanval.m

% The following command computes the estimates using a simplex search method.

[theta2,fval,exitflag,output]  = fminsearch('gmmobjg',theta2, options);

%save prova.mat


%meanval.m has the command, "disp(['# of iterations for delta convergence:  ' num2str(i)])", which shows the iterations it takes to converge in computing the mean utility for each iteration of the main optimization routine. 

%gmmobjg.m has the command "disp(['GMM objective:  ' num2str(f1)])", which shows the value of the moment expression at each meanval.m iteration

comp_t = toc/60;

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                   ')

theta2w = full(sparse(theti,thetj,theta2));

% computing the s.e.

vcov = var_cov_medicare(theta2);
se = sqrt(diag(vcov));
t = size(se,1) - size(theta2,1);
se2w = full(sparse(theti,thetj,se(t+1:size(se,1))));

%var_cov is a separate matlab file
disp(['Object vcov dimensions: ' num2str(size(vcov)) ])
disp(['Object se dimensions: ' num2str(size(se)) ])

disp(['Object theta2w dimensions:     ' num2str(size(theta2w)) ])
disp(['Object t dimensions:     ' num2str(size(t)) ])
disp(['Object se2w dimensions:     ' num2str(size(se2w)) ])

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                   ')

%histogram of the coefficients
alfa_i=[];
alfa_i2=[];
alfa_i_counterfactual=[];
alfa_i2_counterfactual=[];
for i=1:nmkt
    data_market=reshape(demogr(i,1:ns*(length(theta2w)-1)),ns,(length(theta2w)-1));
    v_market=reshape(v(i,1:ns),ns,1); % caution: v is created to have 1000 columns
    alfa_i2=[alfa_i2 ; data_market*(theta2w(1,2:end)')+theta2w(1,1)*v_market(:,1)];
    alfa_i=[alfa_i ; data_market*(theta2w(1,2:end)')];
    %calculate alfa_i for the counterfactual market
    data_market_counterfactual=reshape(demogr_counterfactual(i,1:ns*(length(theta2w)-1)),ns,(length(theta2w)-1));
    alfa_i2_counterfactual=[alfa_i2_counterfactual ; data_market_counterfactual*(theta2w(1,2:end)')+theta2w(1,1)*v_market(:,1)];
    alfa_i_counterfactual=[alfa_i_counterfactual ; data_market_counterfactual*(theta2w(1,2:end)')];
end
alfa_i=(theta1(2)+alfa_i2)/100;
alfa_i_counterfactual=(theta1(2)+alfa_i2_counterfactual)/100;
index=find(alfa_i>0);
%alfa_i(index)=-alfa_i(index);
index=find(alfa_i_counterfactual>0);
%alfa_i_counterfactual(index)=-alfa_i_counterfactual(index);
hist(alfa_i, 25)
title('Distribution of the price coefficient - 2007', 'FontSize', 14);
xlabel('Values', 'FontSize', 12)
ylabel('Frequency', 'FontSize', 12)
%xlim([-0.11 -0.08])
%compute the elasticities
%reshape the alfas
alfa_i_reshaped=reshape(alfa_i,ns,length(cdindex))';
alfa_i_reshaped=alfa_i_reshaped(cdid,:);
alfa_i_counterfactual_reshaped=reshape(alfa_i_counterfactual,ns,length(cdindex))';
alfa_i_counterfactual_reshaped=alfa_i_counterfactual_reshaped(cdid,:);
load mvalold
load gmmresid gmmresid
expmu = exp(mufunc(x2,theta2w));
f = ind_sh(mvalold,expmu);
unobservable_component=gmmresid;
mval=(x1*theta1);
f2 = sum((ind_sh(exp(mval+gmmresid),expmu))')/ns;
f2 = f2';
error=s_jt-f2;

save(sprintf('myBLP_results_%.0e_search_original.mat',mtol))
input.data = [[theta1;theta2'],se];
latexTable(input)
disp(['The value of the objective function at the optimum:     ' num2str(fval)])


% Add n_medications_col to X1 


%Stop Here!

% omega_matrix = mktsh_elasticities(mvalold,expmu,alfa_i_reshaped*100, data(:,[price_col]));
% prices_lis=max(data(:,[price_col])-data(:,[lis_col])/100,0);
% omega_matrix_lischoosers = mktsh_elasticities_lischoosers(prices_lis, alfa_i_counterfactual_reshaped*100, data(:,true_weight_col),data(:,gamma_col),demogr_counterfactual,cdid_demogr,theta2w);
% omega_final=omega_matrix+omega_matrix_lischoosers;
% a=diag(omega_matrix);
% sum(a>0)
% sum(alfa_i>0)
% theta1(2)
% se(2)
% theta2w
% reshape(se(end-(length(theta2w)-1):end),1,(length(theta2w)))
% 
% %%%invert the market shares
% %all different owners
% %ownership_matrix=diag(ones(length(s_jt),1));
% 
% %monopolist
% % ownership_matrix=diag(ones(length(s_jt),1));
% % old_index=0;
% % for i=1:length(cdindex)
% %     index=(old_index+1):cdindex(i);
% %     ownership_matrix(index,index)=1;
% %     old_index=cdindex(i);
% % end
% 
% %true ownership
% dummy_firm_matrix=data(:,dummy_firm_start:dummy_firm_end);
% ownership_matrix=diag(ones(length(s_jt),1));
% for i=1:size(ownership_matrix,1)-1
%     company1=find(dummy_firm_matrix(i,:)==1);
%     for ii=i+1:size(ownership_matrix,1)
%         company2=find(dummy_firm_matrix(ii,:)==1);
%         if company1==company2
%             ownership_matrix(i,ii)=1;
%             ownership_matrix(ii,i)=1;
%         end
%     end
% end
%     
% %these data are taken from miller and yeo
% prices=data(:,[price_col])*100;
% index=find( data(:,1)>11000000 & data(:,1)<12000000);
% prices(index)=prices(index)+87.05-32.34;
% index=find( data(:,1)>10000000 & data(:,1)<11000000);
% prices(index)=prices(index)+88.33-31.94;
% index=find( data(:,1)>9000000 & data(:,1)<10000000);
% prices(index)=prices(index)+84.33-30.36;
% index=find( data(:,1)>8000000 & data(:,1)<9000000);
% prices(index)=prices(index)+80.52-27.93;
% index=find( data(:,1)>7000000 & data(:,1)<8000000);
% prices(index)=prices(index)+80.43-27.35;
% index=find( data(:,1)>6000000 & data(:,1)<7000000);
% prices(index)=prices(index)+92.3-32.2;
% 
% %enrollment weighted bids 2006-2009
% sum(s_jt(find(sum(data(:,dummy_year_start:dummy_year_start+3),2)==1))/sum(s_jt(find(sum(data(:,dummy_year_start:dummy_year_start+3),2)==1))).*prices(find(sum(data(:,dummy_year_start:dummy_year_start+3),2)==1)))
% sum(s_jt(find(data(:,dummy_year_start+3)==1))/sum(s_jt(find(data(:,dummy_year_start+3)==1))).*prices(find(data(:,dummy_year_start+3)==1)))
% 
% 
% markup=[];
% old_index=0;
% marginal_costs=[];
% lis_adjustment=0.13;
% for i=1:length(cdindex)
%     index=(old_index+1):cdindex(i);
% %    markup=[markup ; (ownership_matrix(index,index).*-omega_matrix(index,index)+(kron(1-data(index,indicator_bench_col),ones(1,length(index)))).*ownership_matrix(index,index).*-omega_matrix_lischoosers(index,index))^(-1)...
% %        *(s_jt(index)+(1-data(index,indicator_bench_col)).*data(index,ms_lischoosers_col)+(data(index,indicator_bench_col)).*data(index,ms_lis_col))];
% %    markup=[markup ; (ownership_matrix(index,index).*-omega_matrix(index,index).*kron(data(index,market_sizes_col),ones(1,length(index)))+(kron(1-data(index,indicator_bench_col),ones(1,length(index)))).*ownership_matrix(index,index).*-omega_matrix_lischoosers(index,index).*kron(data(index,tot_lis_choosers_col),ones(1,length(index))))^(-1)...
% %        *(s_jt(index).*data(index,market_sizes_col)+(1-data(index,indicator_bench_col)).*data(index,ms_lischoosers_col).*data(index,tot_lis_choosers_col)+data(index,indicator_bench_col).*data(index,ms_lis_col).*data(index,tot_lis_col))];
%     %%%%%%%%%%%%%%%%%%%%%%%%%
%     %create an indicator vector for price above benchmark
%     below_benchmark_indicator_vector=data(index,indicator_bench_col) ; %=1 if below benchmark plan
%     %re-nomarlize the market shares such that all market shares are in
%     %terms of the entire population over 65
%     tot_pop_over65=data(index,market_sizes_col)+data(index,tot_lis_col);
%     market_shares=s_jt(index).*data(index,market_sizes_col)./tot_pop_over65;
%     market_shares_l=data(index,ms_lis_col).*data(index,tot_lis_col)./tot_pop_over65;
%     market_shares_lc=data(index,ms_lischoosers_col).*data(index,tot_lis_choosers_col)./tot_pop_over65;
%     %calculate the denominator of the expression for the costs
%     denominator=ownership_matrix(index,index).*omega_matrix(index,index).*data(index(1),market_sizes_col)./tot_pop_over65(1)...
%         +kron(1-below_benchmark_indicator_vector,ones(1,length(index))).*ownership_matrix(index,index).*omega_matrix_lischoosers(index,index).*data(index(1),tot_lis_choosers_col)./tot_pop_over65(1)*(1+lis_adjustment);
%     %calculate the numerator of the expression for the costs
%     numerator1=market_shares+below_benchmark_indicator_vector.*market_shares_l+(1-below_benchmark_indicator_vector).*market_shares_lc;
%     numerator2=ownership_matrix(index,index).*omega_matrix(index,index).*data(index(1),market_sizes_col)./tot_pop_over65(1)...
%         +kron(1-below_benchmark_indicator_vector,ones(1,length(index))).*ownership_matrix(index,index).*omega_matrix_lischoosers(index,index).*data(index(1),tot_lis_choosers_col)./tot_pop_over65(1);
%     marginal_costs=[marginal_costs ; denominator^(-1)*(numerator1+numerator2*data(index,bid_col))];
%     if sum(isnan(marginal_costs))>0
%        % error
%     end
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     old_index=cdindex(i);
%     
%     
% end
% indicator_banch_only=data(:,indicator_bench_col);
% bids_only=data(:,bid_col);
% markup=data(:,bid_col)-marginal_costs;
% markup_perc=markup./data(:,bid_col);
% 
% 
% 
% control=find(data(:,groupA_col)==0);
% index=find( data(:,1)>8000000 & data(:,1)<9000000);
% index_final=intersect(control,index)
% hist(markup_perc(index_final),500)
% xlim([0 0.5])
% sum(markup<0)
% 
% hist(markup_perc,100)
% %SOME GRAPHS
% % unit_markup=markup;%./(data(:,tot_lis_choosers_col)+data(:,market_sizes_col)); %(1-data(:,indicator_bench_col)).*
% % unit_markup_enhance=unit_markup(find(data(:,d_enhance_col)==0.01));
% % unit_markup_basic=unit_markup(find(data(:,d_enhance_col)==0));
% % unit_markup_planlc=unit_markup(find(data(:,ms_lischoosers_col)>0));
% % unit_markup_plannonlc=unit_markup(find(data(:,ms_lischoosers_col)==0));
% % 
% % [n,xout]=hist(unit_markup,100);
% % bar(xout,n/sum(n))
% % 
% % [n,xout]=hist(unit_markup_plannonlc,100);
% % subplot(1,2,1), bar(xout,n/sum(n))
% % 
% % [n,xout]=hist(unit_markup_planlc,100);
% % subplot(1,2,2), bar(xout,n/sum(n))
% % 
% % [n,xout]=hist(unit_markup_basic,100);
% % subplot(1,2,1), bar(xout,n/sum(n))
% % set(gca,'Fontsize',14)
% % %title(['Unit mark-ups basic plans'],'Fontsize',18)
% % %saveas(gcf,'markups_basics','pdf')
% % [n,xout]=hist(unit_markup_enhance,100);
% % subplot(1,2,2), bar(xout,n/sum(n))
% % %title(['Unit mark-ups enhanced plans'],'Fontsize',18)
% % set(gca,'Fontsize',14)
% % %saveas(gcf,'markups_enhance','pdf')
% 
% mc=marginal_costs;
% 
% save BLP_results.mat


%define the colums containing the variables
id_app=1; %id market plan
id_market=2; %id market (country for each year)
ms=3; %market shares
price=4; %price
developer=5; %developer name 
average_score=6; %average score
nofreviews=7; %number of reviews
iap=8; %dummy for in-app purchases
country=9; %country 
year=10; %year
nest=11; %nest of apps
new_est=12; %estimated number of downloads
multiplyier=13; %multiplyier
 
