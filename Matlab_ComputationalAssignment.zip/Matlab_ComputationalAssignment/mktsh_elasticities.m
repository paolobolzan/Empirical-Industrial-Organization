function omega_matrix = mktsh_elasticities(mval, expmu, alfa_i_reshaped, prices)
% This function computes the market share for each product
%
% Written by Aviv Nevo, May 1998.
global ns cdid

market_shares=mktsh(mval,expmu);
%omega_matrix=diag(prices./market_shares.* sum(alfa_i_reshaped.*ind_sh(mval,expmu).*(1-ind_sh(mval,expmu)),2))/ns;
omega_matrix=diag(sum(alfa_i_reshaped.*ind_sh(mval,expmu).*(1-ind_sh(mval,expmu)),2))/ns;
%these are the diagonal elements of omega matrix 
f = ind_sh(mval,expmu);
for i=1:length(cdid)
    for ii=i+1:length(cdid)
        if cdid(i)==cdid(ii)
            %omega_matrix(i,ii)=prices(ii)/market_shares(i)*sum(-alfa_i_reshaped(cdid(i), :).*f(i,:).*f(ii,:))/ns;
            %omega_matrix(ii,i)=prices(i)/market_shares(ii)*sum(-alfa_i_reshaped(cdid(ii), :).*f(ii,:).*f(i,:))/ns;
            omega_matrix(i,ii)=sum(-alfa_i_reshaped(cdid(i), :).*f(i,:).*f(ii,:))/ns;
            omega_matrix(ii,i)=sum(-alfa_i_reshaped(cdid(ii), :).*f(ii,:).*f(i,:))/ns;

        else
            omega_matrix(i,ii)=0;
        end
        
    end
end

%omega_matrix=omega_matrix;