% This program estimates BLP using Medicare part D data.
% It is a twisted and adapted version of the set of codes accompanying "A Research Assistant's Guide to Discrete Choice Models of Demand," 
% INPUTS: 
% - data: (/Users/fdc/Dropbox/MedicarePartD/static_BLP/data/data_BLP.mat) 
%                # rows = # of plans, # columns = # of plans' characteristics
%                created by do_data_BLP.do

% CODE PARTS:
% - line ~40-110: name columnes of data;
% - line ~110-160: drop missing IV, pick years used for estimation,
%                  construct the matrices x1: plan's characterisctis used for estimation;
%                  x2: plan's characterisctis interacted with demographics, theta2w starting
%                  point for the optimization of the parameters interacted with demographics
%                  # rows: of plans's characteristics interacted, # columns: # of demographics
%                  load demographics.
% - line ~160-370: initialization and estimation
% - line ~370 onward: inversion of the supply side to obtain marginal costs

% OUTPUTS:
% - BLP_results.mat: dataset with all the results
% - theta1: vector of estimated parameters for the indiriect utility function, length: # of plans's characteristics 
% - theta2: matrix of estimated interaction with demographicsparameters for
%           the indiriect utility function, # rows: of plans's characteristics
%           interacted, # columns: # of demographics
% - se: matrix of standard errors
% - alfa_i_reshaped: estimated distribution of the price coefficient
%                    (interacted with the demographics)
% - mc: vector of estimated marginal costs, length: # of plans

% cd('/Users/jinchuqing/Dropbox/Empirical IO 2/BU2017/Assigment/matlab_codes_data/')
% cluster cd
% cd('/usr3/graduate/cjin/EC733/matlab_code_data/')
clear
clear global
clc

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                    ')

delete mydiary.txt %we don't want any old mydiary.txt file to interfere.
diary mydiary.txt
date = datestr(clock)
global invA ns x1 x2 s_jt IV vfull dfull theta1 theti thetj cdid cdindex v demogr 

%define the colums containing the variables
id_col=1; %id market plan
id_market_col=2; %id market
ms_col=3; %market shares
dummy_firm_start=4; %first column of firm id's dummies
dummy_firm_end=79; %last column of firm id's dummies
dummy_year_start=80; %first column of year's dummies
dummy_year_end=85; %last column of year's dummies
dummy_region_start=86; %first column of region's dummies
dummy_region_end=119; %last column of region's dummies

dummy_firmname_start=120; %first column of firm name 
dummy_firmname_end=140; %last column of firm name


dummy_macroregion_start=141; %first column of firm name 
dummy_macroregion_end=143; %last column of firm name

price_col=144;
deductible_col=price_col+1;
n_medications_col=price_col+2;
drug_frf_col=price_col+3;
d_cov_gap_col=price_col+4;
d_enhance_col=price_col+5;
top_drug_col=price_col+6;
in_area_flag_col=price_col+7;
vintage_col=price_col+8;
tier_12_col=price_col+9;
d_below_lagged_col=price_col+10;
ms_lis_firm_col=price_col+11;
ms_lis_firm_lagged_col=price_col+12;
 
%LIST OF IV'S
%0,4: sum_plans_rj sum_prices_rj sum_deductibles_rj sum_top_drugs_rj  sum_restr_top_drugs_rj
%5,9:  sum_tier_1_top_drugs_rj sum_partDPremium_rj sum_medications_rj sum_plans_rnoj sum_prices_rnoj
%10,14:  sum_deductibles_rnoj sum_top_drugs_rnoj sum_restr_top_drugs_rnoj sum_tier_1_top_drugs_rnoj sum_partDPremium_rnoj
%15,18:  sum_medications_rnoj tot_age sd_age skew_age

	
%very bad IVs:sum_plans_rj_iv, sum_prices_r
%bad IVs: sum_plans_enha_r sum_plans_strd_r
iv_start_col=price_col+13;
iv_end_col=iv_start_col+12;

bid_col=iv_start_col+15;
gamma_col=iv_start_col+16;
true_weight_col=iv_start_col+17;
nat_weight_col=iv_start_col+18;

groupA_col=iv_start_col+19;
group_region_col=iv_start_col+20;
group_bid_test_col=iv_start_col+21;

%%%
ms_lischoosers_col=iv_start_col+22;
tot_lis_col=iv_start_col+23;
tot_lis_choosers_col=iv_start_col+24;
market_sizes_col=iv_start_col+25;
ms_lis_col=iv_start_col+26;
indicator_bench_col=iv_start_col+27; %=1 if below benchmark plan
contract_id_col=iv_start_col+28;
benefit_type_col=iv_start_col+29;
plan_name_col=iv_start_col+30;
lis_col=iv_start_col+31;
% load data

load data_BLP.mat


%iv_start_col+3 and iv_start_col+6 iv_start_col+11 are the mean_drugfrf_ma_rj and total_lis_enrol_j_norpl hausman_instrument_otherregion, so we set
%them to 0 if are nan 
data(find(isnan(data(:,iv_start_col+3))==1),iv_start_col+3)=0;
data(find(isnan(data(:,iv_start_col+6))==1),iv_start_col+6)=0;
data(find(isnan(data(:,iv_start_col+11))==1),iv_start_col+11)=0;
data(find(isnan(data(:,iv_start_col+4))==1),iv_start_col+4)=0;
data(find(isnan(data(:,iv_start_col+5))==1),iv_start_col+5)=0;

index=data(:,1)>11000000 | data(:,1)<7000000; %drop dates
%index=data(:,1)<7000000

data(index,:)=[];
index=find(data(:,in_area_flag_col)==0 | data(:,in_area_flag_col)>10000); %drop plans with no pharmacies
data(index,:)=[];
%used to scale all the variables and avoid numerical Inf
scaling=100;

data(:,[price_col deductible_col n_medications_col drug_frf_col d_cov_gap_col d_enhance_col top_drug_col vintage_col tier_12_col dummy_macroregion_start:dummy_macroregion_end])=data(:,[price_col deductible_col n_medications_col drug_frf_col d_cov_gap_col d_enhance_col top_drug_col vintage_col tier_12_col dummy_macroregion_start:dummy_macroregion_end])/scaling;
data(:,[dummy_year_start:dummy_year_end dummy_region_start:dummy_region_end dummy_firmname_start:dummy_firmname_end])=data(:,[dummy_year_start:dummy_year_end dummy_region_start:dummy_region_end dummy_firmname_start:dummy_firmname_end])/scaling;
data(:,in_area_flag_col)=data(:,[in_area_flag_col])/1000;

%%%original setup
x1=[ones(size(data,1),1) data(:,[price_col deductible_col drug_frf_col d_cov_gap_col d_enhance_col tier_12_col top_drug_col in_area_flag_col vintage_col dummy_macroregion_start:dummy_macroregion_end-1 dummy_year_start+1:dummy_year_end-3 dummy_firmname_start dummy_firmname_start+10 dummy_firmname_start+13 dummy_firmname_start+15 dummy_firmname_start+16 dummy_firmname_end])];

%%%add n_medications_col
%x1=[ones(size(data,1),1) data(:,[price_col n_medications_col deductible_col drug_frf_col d_cov_gap_col d_enhance_col tier_12_col top_drug_col in_area_flag_col vintage_col dummy_macroregion_start:dummy_macroregion_end-1 dummy_year_start+1:dummy_year_end-3 dummy_firmname_start dummy_firmname_start+10 dummy_firmname_start+13 dummy_firmname_start+15 dummy_firmname_start+16 dummy_firmname_end])];



% dummy_firmname_start+15
%for the firm's dummy, I include a dummy for companies with more then 5\%
%at a national level the columes are: dummy_firmname_start,
%dummy_firmname_start+10, dummy_firmname_start+13, dummy_firmname_start+15, dummy_firmname_start+16
%eliminate dummies that are always 0 (companies that never offer a plan in
%2006) 
index=sum(x1);
index=find(index==0);
x1(:,index)=[];

%x2=[data(:,[price_col d_enhance_col top_drug_col restricted_top_drug_col])];
x2=[data(:,[price_col deductible_col])];
% data(:,iv_start_col+16).*data(:,top_drug_col) data(:,iv_start_col+16).*data(:,d_enhance_col)
%IV = [data(:,[iv_start_col:iv_end_col]) data(:,[deductible_col d_cov_gap_col d_enhance_col tier_12_col top_drug_col in_area_flag_col vintage_col dummy_macroregion_start:dummy_macroregion_end-1 dummy_year_start+1:dummy_year_end-3 dummy_firmname_start dummy_firmname_start+10 dummy_firmname_start+13 dummy_firmname_start+16 dummy_firmname_end])];
%IV = [data(:,[iv_start_col:iv_start_col+3 iv_start_col+6:iv_end_col])  data(:,[iv_start_col+7:iv_start_col+10]) data(:,[iv_end_col]) data(:,[deductible_col drug_frf_col d_cov_gap_col d_enhance_col top_drug_col in_area_flag_col vintage_col dummy_year_start+1:dummy_year_end-2 dummy_firmname_start dummy_firmname_start+10 dummy_firmname_start+13 dummy_firmname_start+16 ])]; %
IV = [data(:,[iv_start_col:iv_end_col]) data(:,[ deductible_col d_cov_gap_col d_enhance_col tier_12_col top_drug_col in_area_flag_col vintage_col dummy_macroregion_start:dummy_macroregion_end-1 dummy_year_start+1:dummy_year_end-3 dummy_firmname_start dummy_firmname_start+10 dummy_firmname_start+13 dummy_firmname_start+16 dummy_firmname_end])];
%  iv_start_col+18:iv_start_col+20  iv_start_col+9:iv_start_col+15
%these columns give non singuality: 7-11
IV=IV(:,[1:6 12:end]);

index=sum(isnan(IV'));
data(find(index>0),:)=[];
IV(find(index>0),:)=[];
x1(find(index>0),:)=[];
x2(find(index>0),:)=[];

id=data(:,id_col);
id_demo=unique(data(:,id_market_col));
s_jt=data(:,ms_col);

%theta2w=    [1 -1 1]; 
%First elemnet is the guess for the estimate of the constant; Second element is the guess of the intercation between the element of X2 and the first demographic; Third element guess of the estimate of the interaction of the first element of X2 with the second element of the demogrtaphics
theta2w=    [1 -1 1 ; 
             1 -0.5 1];

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                    ')

%random demographics
load demographics_medicare
load random_demographics_medicare

%rescale income, which is in the first ns positions by construction
demogr(:,1:ns)=demogr(:,1:ns)/1000;
demogr_means(:,1:ns)=demogr_means(:,1:ns)/1000;

%counterfactual demographics
load demographics_medicare_poor
demogr_counterfactual(:,1:ns)=demogr_counterfactual(:,1:ns)/1000;
demogr_means_counterfactual(:,1:ns)=demogr_means_counterfactual(:,1:ns)/1000;

demogr_counterfactual=demogr_counterfactual+demogr_means_counterfactual-demogr_means;

%save random_demographics v demogr
%load random_demographics


% The  vector  below relates each observation to the market it is in 

cdid=[];
cdid_demogr=[];
cdindex=0;
for i=1:length(id_demo)
   nbrand_market=sum(data(:,id_market_col)==id_demo(i));
   cdid=[cdid ; i*ones(nbrand_market,1)];
   cdindex=[cdindex ; cdindex(end)+nbrand_market];
   %create the cdid for the demographics
   index_market=find(data(:,id_market_col)==id_demo(i));
   index_region=find(data(index_market(1),dummy_region_start:dummy_region_end)==(1/scaling));
   index_year=find(data(index_market(1),dummy_year_start:dummy_year_end)==(1/scaling))+2005;
   index_demogr=find(demogr_year_region_id(:,1)==(index_year-1) & demogr_year_region_id(:,2)==index_region);
   if isempty(index_demogr)
       error(['Demographics not found for region ' num2str(index_region) ' and year ' num2str(index_year)])
   end
   cdid_demogr=[cdid_demogr ; index_demogr*ones(nbrand_market,1)];
end
cdindex(1)=[];

disp(['Object cdid dimensions: ' num2str(size(cdid)) ])

% the vector below provides for each index the of the last observation   in the data  

disp(['The dimensions of object cdindex are      ' num2str(size(cdindex)) ])

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                   ')

% starting values. zero elements in the following matrix correspond to
% coeff that will not be max over,i.e are fixed at zero.  The defaults are in %comments here

disp('                                                                    ')
disp(['The dimensions of object theta2w are      ' num2str(size(theta2w)) ])
disp('                                                                    ')

% create a vector of the non-zero elements in the above matrix, and the
% corresponding row and column indices. this facilitates passing values %
% to the functions below. %

[theti, thetj, theta2]=find(theta2w);

%nmkt = size(demogr,1);     % number of markets = (# of years)*(# of regionid)  %
nmkt = length(id_demo);
vfull = v(cdid_demogr,:);
dfull = demogr(cdid_demogr,:);

%create instruments based on demographics
mean_income=demogr_means(cdid_demogr,1);
mean_diffall=demogr_means(cdid_demogr,ns+1);
%mean_diffall=demogr_means(cdid_demogr,2*ns+1);
std_income=demogr_std(cdid_demogr,1);
%std_marital=demogr_std(cdid_demogr,ns+1);
%std_diffall=demogr_std(cdid_demogr,2*ns+1);
iqr_income=demogr_iqr(cdid_demogr,1);
iqr_diffall=demogr_iqr(cdid_demogr,ns+1);
%IV=[IV IV(:,14).*mean_income IV(:,14).*mean_marital IV(:,14).*mean_diffill IV(:,14).*std_income];
%IV(:,7)=[];
IV=[IV IV(:,14).*mean_income IV(:,14).*mean_diffall IV(:,14).*iqr_income IV(:,14).*iqr_diffall];
%note that the 14th IV is in_area_flag, the number of affiliated
%pharmacies/1000.

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                   ')

n_inst = size(IV,2);   %Number of instruments for price

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                    ')

disp(['The dimensions of object IV are ' num2str(size(IV)) ])

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                    ')

% create weight matrix
invA = inv(IV'*IV);
%mid2 = x1'*IV*invA*IV'*x1;
%inv(mid2);

disp(['The dimensions of object invA  are ' num2str(size(invA)) ])

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                   ')

% Logit results and save the mean utility as initial values for the
%search below.

% compute the outside good market share by market:

temp = cumsum(s_jt);
sum1 = temp(cdindex,:);
sum1(2:size(sum1,1),:) = diff(sum1);
outshr = 1.0 - sum1(cdid,:);
outshr=abs(outshr);
disp(['Object temp dimensions: ' num2str(size(temp)) ])
disp(['Object sum1 dimensions: ' num2str(size(sum1)) ])
disp(['Object outshr dimensions: ' num2str(size(outshr)) ])


y = log(s_jt) - log(outshr);

mid = x1'*IV*invA*IV';
t = (mid*x1)\(mid*y);
mvalold = x1*t;
oldt2 = zeros(size(theta2));
mvalold = exp(mvalold);

 %s_jt and outshr and x1 are  data that Nevo provides

disp(['Object y dimensions: ' num2str(size(y)) ])
disp(['Object mid dimensions: ' num2str(size(mid)) ])
disp(['Object t dimensions: ' num2str(size(t)) ])
disp(['Object mvalold dimensions: ' num2str(size(mvalold)) ])
disp(['Object oldt2 dimensions: ' num2str(size(oldt2)) ])

%the next command creates a new file, mvalold.mat, with mvaoldold and oldt2 in it, and then clears out the old mvalold from memory. 

save mvalold mvalold oldt2
clear mid y outshr t oldt2 mvalold temp sum1

% the matrix v has 80 iid normal random numbers for each of the 94 observations
% the matrix demogr has random draws from the CPS for 20 individuals per obs.

disp(['Object vfull dimensions: ' num2str(size(vfull)) ])
disp(['Object dfull dimensions: ' num2str(size(dfull)) ])

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                   ')

%Below,   set the maximum number of iterations for the main optimization command. Note .that the number of iterations for the meanval.m calculation is separate, and unconstrained. 

options = optimset('GradObj','off','MaxIter',150,'Display','iter','TolFun',0.01,'TolX',0.01);
tic

%gmmobjg.m  is a  separate matlab file created by Bronwyn Hall to %replace  Nevo's gmmobj.m and gradobj.m with one file for Matlab 6 or 7.
%gmmobjg calls up meanval.m

% The following command computes the estimates using a simplex search method.

[theta2,fval,exitflag,output]  = fminsearch('gmmobjg',theta2, options);

%save prova.mat


%meanval.m has the command, "disp(['# of iterations for delta convergence:  ' num2str(i)])", which shows the iterations it takes to converge in computing the mean utility for each iteration of the main optimization routine. 

%gmmobjg.m has the command "disp(['GMM objective:  ' num2str(f1)])", which shows the value of the moment expression at each meanval.m iteration

comp_t = toc/60;

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                   ')

theta2w = full(sparse(theti,thetj,theta2));

% computing the s.e.

vcov = var_cov_medicare(theta2);
se = sqrt(diag(vcov));
t = size(se,1) - size(theta2,1);
se2w = full(sparse(theti,thetj,se(t+1:size(se,1))));

%var_cov is a separate matlab file
disp(['Object vcov dimensions: ' num2str(size(vcov)) ])
disp(['Object se dimensions: ' num2str(size(se)) ])

disp(['Object theta2w dimensions:     ' num2str(size(theta2w)) ])
disp(['Object t dimensions:     ' num2str(size(t)) ])
disp(['Object se2w dimensions:     ' num2str(size(se2w)) ])

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                   ')

%histogram of the coefficients
alfa_i=[];
alfa_i2=[];
alfa_i_counterfactual=[];
alfa_i2_counterfactual=[];
for i=1:nmkt
    data_market=reshape(demogr(i,1:ns*(length(theta2w)-1)),ns,(length(theta2w)-1));
    v_market=reshape(v(i,1:ns),ns,1); % caution: v is created to have 1000 columns
    alfa_i2=[alfa_i2 ; data_market*(theta2w(1,2:end)')+theta2w(1,1)*v_market(:,1)];
    alfa_i=[alfa_i ; data_market*(theta2w(1,2:end)')];
    %calculate alfa_i for the counterfactual market
    data_market_counterfactual=reshape(demogr_counterfactual(i,1:ns*(length(theta2w)-1)),ns,(length(theta2w)-1));
    alfa_i2_counterfactual=[alfa_i2_counterfactual ; data_market_counterfactual*(theta2w(1,2:end)')+theta2w(1,1)*v_market(:,1)];
    alfa_i_counterfactual=[alfa_i_counterfactual ; data_market_counterfactual*(theta2w(1,2:end)')];
end
alfa_i=(theta1(2)+alfa_i2)/100;
alfa_i_counterfactual=(theta1(2)+alfa_i2_counterfactual)/100;
index=find(alfa_i>0);
%alfa_i(index)=-alfa_i(index);
index=find(alfa_i_counterfactual>0);
%alfa_i_counterfactual(index)=-alfa_i_counterfactual(index);
hist(alfa_i, 25)
title('Distribution of the price coefficient - 2007', 'FontSize', 14);
xlabel('Values', 'FontSize', 12)
ylabel('Frequency', 'FontSize', 12)
%xlim([-0.11 -0.08])
%compute the elasticities
%reshape the alfas
alfa_i_reshaped=reshape(alfa_i,ns,length(cdindex))';
alfa_i_reshaped=alfa_i_reshaped(cdid,:);
alfa_i_counterfactual_reshaped=reshape(alfa_i_counterfactual,ns,length(cdindex))';
alfa_i_counterfactual_reshaped=alfa_i_counterfactual_reshaped(cdid,:);
load mvalold
load gmmresid gmmresid
expmu = exp(mufunc(x2,theta2w));
f = ind_sh(mvalold,expmu);
unobservable_component=gmmresid;
mval=(x1*theta1);
f2 = sum((ind_sh(exp(mval+gmmresid),expmu))')/ns;
f2 = f2';
error=s_jt-f2;

save myBLP_results_newx2.mat
%input.data = [[theta1;theta2'],se];
%latexTable(input)
disp(['The value of the objective function at the optimum:     ' num2str(fval)])




%Stop Here!

% omega_matrix = mktsh_elasticities(mvalold,expmu,alfa_i_reshaped*100, data(:,[price_col]));
% prices_lis=max(data(:,[price_col])-data(:,[lis_col])/100,0);
% omega_matrix_lischoosers = mktsh_elasticities_lischoosers(prices_lis, alfa_i_counterfactual_reshaped*100, data(:,true_weight_col),data(:,gamma_col),demogr_counterfactual,cdid_demogr,theta2w);
% omega_final=omega_matrix+omega_matrix_lischoosers;
% a=diag(omega_matrix);
% sum(a>0)
% sum(alfa_i>0)
% theta1(2)
% se(2)
% theta2w
% reshape(se(end-(length(theta2w)-1):end),1,(length(theta2w)))
% 
% %%%invert the market shares
% %all different owners
% %ownership_matrix=diag(ones(length(s_jt),1));
% 
% %monopolist
% % ownership_matrix=diag(ones(length(s_jt),1));
% % old_index=0;
% % for i=1:length(cdindex)
% %     index=(old_index+1):cdindex(i);
% %     ownership_matrix(index,index)=1;
% %     old_index=cdindex(i);
% % end
% 
% %true ownership
% dummy_firm_matrix=data(:,dummy_firm_start:dummy_firm_end);
% ownership_matrix=diag(ones(length(s_jt),1));
% for i=1:size(ownership_matrix,1)-1
%     company1=find(dummy_firm_matrix(i,:)==1);
%     for ii=i+1:size(ownership_matrix,1)
%         company2=find(dummy_firm_matrix(ii,:)==1);
%         if company1==company2
%             ownership_matrix(i,ii)=1;
%             ownership_matrix(ii,i)=1;
%         end
%     end
% end
%     
% %these data are taken from miller and yeo
% prices=data(:,[price_col])*100;
% index=find( data(:,1)>11000000 & data(:,1)<12000000);
% prices(index)=prices(index)+87.05-32.34;
% index=find( data(:,1)>10000000 & data(:,1)<11000000);
% prices(index)=prices(index)+88.33-31.94;
% index=find( data(:,1)>9000000 & data(:,1)<10000000);
% prices(index)=prices(index)+84.33-30.36;
% index=find( data(:,1)>8000000 & data(:,1)<9000000);
% prices(index)=prices(index)+80.52-27.93;
% index=find( data(:,1)>7000000 & data(:,1)<8000000);
% prices(index)=prices(index)+80.43-27.35;
% index=find( data(:,1)>6000000 & data(:,1)<7000000);
% prices(index)=prices(index)+92.3-32.2;
% 
% %enrollment weighted bids 2006-2009
% sum(s_jt(find(sum(data(:,dummy_year_start:dummy_year_start+3),2)==1))/sum(s_jt(find(sum(data(:,dummy_year_start:dummy_year_start+3),2)==1))).*prices(find(sum(data(:,dummy_year_start:dummy_year_start+3),2)==1)))
% sum(s_jt(find(data(:,dummy_year_start+3)==1))/sum(s_jt(find(data(:,dummy_year_start+3)==1))).*prices(find(data(:,dummy_year_start+3)==1)))
% 
% 
% markup=[];
% old_index=0;
% marginal_costs=[];
% lis_adjustment=0.13;
% for i=1:length(cdindex)
%     index=(old_index+1):cdindex(i);
% %    markup=[markup ; (ownership_matrix(index,index).*-omega_matrix(index,index)+(kron(1-data(index,indicator_bench_col),ones(1,length(index)))).*ownership_matrix(index,index).*-omega_matrix_lischoosers(index,index))^(-1)...
% %        *(s_jt(index)+(1-data(index,indicator_bench_col)).*data(index,ms_lischoosers_col)+(data(index,indicator_bench_col)).*data(index,ms_lis_col))];
% %    markup=[markup ; (ownership_matrix(index,index).*-omega_matrix(index,index).*kron(data(index,market_sizes_col),ones(1,length(index)))+(kron(1-data(index,indicator_bench_col),ones(1,length(index)))).*ownership_matrix(index,index).*-omega_matrix_lischoosers(index,index).*kron(data(index,tot_lis_choosers_col),ones(1,length(index))))^(-1)...
% %        *(s_jt(index).*data(index,market_sizes_col)+(1-data(index,indicator_bench_col)).*data(index,ms_lischoosers_col).*data(index,tot_lis_choosers_col)+data(index,indicator_bench_col).*data(index,ms_lis_col).*data(index,tot_lis_col))];
%     %%%%%%%%%%%%%%%%%%%%%%%%%
%     %create an indicator vector for price above benchmark
%     below_benchmark_indicator_vector=data(index,indicator_bench_col) ; %=1 if below benchmark plan
%     %re-nomarlize the market shares such that all market shares are in
%     %terms of the entire population over 65
%     tot_pop_over65=data(index,market_sizes_col)+data(index,tot_lis_col);
%     market_shares=s_jt(index).*data(index,market_sizes_col)./tot_pop_over65;
%     market_shares_l=data(index,ms_lis_col).*data(index,tot_lis_col)./tot_pop_over65;
%     market_shares_lc=data(index,ms_lischoosers_col).*data(index,tot_lis_choosers_col)./tot_pop_over65;
%     %calculate the denominator of the expression for the costs
%     denominator=ownership_matrix(index,index).*omega_matrix(index,index).*data(index(1),market_sizes_col)./tot_pop_over65(1)...
%         +kron(1-below_benchmark_indicator_vector,ones(1,length(index))).*ownership_matrix(index,index).*omega_matrix_lischoosers(index,index).*data(index(1),tot_lis_choosers_col)./tot_pop_over65(1)*(1+lis_adjustment);
%     %calculate the numerator of the expression for the costs
%     numerator1=market_shares+below_benchmark_indicator_vector.*market_shares_l+(1-below_benchmark_indicator_vector).*market_shares_lc;
%     numerator2=ownership_matrix(index,index).*omega_matrix(index,index).*data(index(1),market_sizes_col)./tot_pop_over65(1)...
%         +kron(1-below_benchmark_indicator_vector,ones(1,length(index))).*ownership_matrix(index,index).*omega_matrix_lischoosers(index,index).*data(index(1),tot_lis_choosers_col)./tot_pop_over65(1);
%     marginal_costs=[marginal_costs ; denominator^(-1)*(numerator1+numerator2*data(index,bid_col))];
%     if sum(isnan(marginal_costs))>0
%        % error
%     end
%     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     old_index=cdindex(i);
%     
%     
% end
% indicator_banch_only=data(:,indicator_bench_col);
% bids_only=data(:,bid_col);
% markup=data(:,bid_col)-marginal_costs;
% markup_perc=markup./data(:,bid_col);
% 
% 
% 
% control=find(data(:,groupA_col)==0);
% index=find( data(:,1)>8000000 & data(:,1)<9000000);
% index_final=intersect(control,index)
% hist(markup_perc(index_final),500)
% xlim([0 0.5])
% sum(markup<0)
% 
% hist(markup_perc,100)
% %SOME GRAPHS
% % unit_markup=markup;%./(data(:,tot_lis_choosers_col)+data(:,market_sizes_col)); %(1-data(:,indicator_bench_col)).*
% % unit_markup_enhance=unit_markup(find(data(:,d_enhance_col)==0.01));
% % unit_markup_basic=unit_markup(find(data(:,d_enhance_col)==0));
% % unit_markup_planlc=unit_markup(find(data(:,ms_lischoosers_col)>0));
% % unit_markup_plannonlc=unit_markup(find(data(:,ms_lischoosers_col)==0));
% % 
% % [n,xout]=hist(unit_markup,100);
% % bar(xout,n/sum(n))
% % 
% % [n,xout]=hist(unit_markup_plannonlc,100);
% % subplot(1,2,1), bar(xout,n/sum(n))
% % 
% % [n,xout]=hist(unit_markup_planlc,100);
% % subplot(1,2,2), bar(xout,n/sum(n))
% % 
% % [n,xout]=hist(unit_markup_basic,100);
% % subplot(1,2,1), bar(xout,n/sum(n))
% % set(gca,'Fontsize',14)
% % %title(['Unit mark-ups basic plans'],'Fontsize',18)
% % %saveas(gcf,'markups_basics','pdf')
% % [n,xout]=hist(unit_markup_enhance,100);
% % subplot(1,2,2), bar(xout,n/sum(n))
% % %title(['Unit mark-ups enhanced plans'],'Fontsize',18)
% % set(gca,'Fontsize',14)
% % %saveas(gcf,'markups_enhance','pdf')
% 
% mc=marginal_costs;
% 
% save BLP_results.mat
