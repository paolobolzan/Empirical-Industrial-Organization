function [f,df]=gmm(theta,BLPdata)

% gmm
% This function is used to calculate the GMM estimator and its gradient
% Written by Mathias Reynaert (2013)
% Original Source: Aviv Nevo (2000)

%% Contraction Mapping
d=delta(theta,BLPdata);
%% GMM
if max(isnan(d)) == 1
 f = 1e10;	  
else 
%Use relationship between linear and non-linear parameters from step 4,
%resulting from the FOC's
    bet = BLPdata.invxzwzx*(BLPdata.xzwz*d);
    csi = d-BLPdata.Xexo*bet;
	f = csi'*BLPdata.Z*BLPdata.W*BLPdata.Z'*csi;
    save bet bet;
end
%% Gradient
if max(isnan(d)) == 1
    df=1e10;
elseif nargout>1
        temp = jacob(theta,d,BLPdata)'; % ncol(temp) = number of products nrow(temp) = number of random coeff
        df = 2*temp*BLPdata.Z*BLPdata.W*BLPdata.Z'*csi;
end

end

