clear 
clear global 
clc

input.dataFormat = {'%.3f',9};
input.tableColLabels = {'Original','Newton_5e-16_1','Newton_5e-16_2','Newton_5e-16_3','Newton_5e-16_4',... 
    'Newton_5e-16_5','Newton_1e-16_1','Newton_1e-14_1','Chamberlain'};
%input.tableRowLabels = {
input.dataNanString = '';
input.tableCaption = 'BLP Estimates with Alternative Starting Values and Tolerance Levels';
input.tableLabel = 'tab:blpdiagnostics';
input.tableBorders = 0;

load myBLP_results_5e-16_search_original.mat
[f,df] = gmmobjg(theta2);
input.data = [theta2';theta1;f;df];

tolerance = [5e-16, 5e-16, 5e-16, 5e-16, 5e-16, 1e-16, 1e-14];
startvalueid = [1:5,1,1];

for i = 1:7
load(sprintf('myBLP_results_%.0e_newton_%.0e.mat',tolerance(i),startvalueid(i)));
%sprintf('myBLP_results_%.0e_newton_%.0e.mat',tolerance(i),startvalueid(i))
[f,df] = gmmobjg(theta2);
input.data = [input.data,[theta2';theta1;f;df]];
end

load myBLP_results_5e-16_newton_optiv_1e+00.mat
[f,df] = gmmobjg(theta2);
input.data = [input.data,[theta2';theta1;f;df]];
save input2_3 input
clear 
load input2_3
latexTable(input);

