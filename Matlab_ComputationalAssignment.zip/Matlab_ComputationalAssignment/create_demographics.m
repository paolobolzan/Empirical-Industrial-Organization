%this code creates the demographics for the BLP estimation of Medicare Part
%D program
clear
clc
%%%select the year and number fo individuals
ciao
ns=500;

%load /Users/nicolabranzoli/Dropbox/static_BLP/data/demographics_BLP.mat
load demographics_BLP.mat
all_years_selected=[2006 2007 2008 2009];
variables_interests='[hhincome_col age_col];'; % THIS IS WHERE YOU SLECT WHICH DEMORGAPHICS YOU WILL USE
weight_col=1;
regionid_col=2;
year_col=3; 
age_col=4; 
sex_col=5; 
marst_col=6; %marital status
race_col=7;
% White	1
% Black/Negro	2
% American Indian or Alaska Native	3
% Chinese	4
% Japanese	5
% Other Asian or Pacific Islander	6
% Other race, nec	7
% Two major races	8
% Three or more major races	9

hcovany_col=8; %if it has or has not coverage (NOTE: not available for 2005)
hcovpriv_col=9; %private coverage
hinsemp_col=10; %...provided by the employer
hinscare_col=11; %(likely) if it has medicare
educ_col=12;
%values for education:
% 0	N/A or no schooling
% 1	Nursery school to grade 4
% 2	Grade 5, 6, 7, or 8
% 3	Grade 9
% 4	Grade 10
% 5	Grade 11
% 6	Grade 12
% 7	1 year of college
% 8	2 years of college
% 10	4 years of college
% 11	5+ years of college

empstat_col=13; 
% 1	Employed
% 2	Unemployed
% 3	Not in labor force
hhincome_col=14; %4 measures of income
inctot_col=15; 
ftotinc_col=16; 
incretir_col=17; 
diffrem_col=18;  %cognitive difficulty
diffphys_col=19;  % ambulatory difficulty
diffmob_col=20;  %indipendent living or not
diffcare_col=21;  %? (yer or no)
diffsens_col=22; %hearing or vision difficulty
hispanic_col=23; %hispanic (0 is not hispanic)

diffall=data(:,diffrem_col)+data(:,diffphys_col)+data(:,diffmob_col)+data(:,diffcare_col)+data(:,diffsens_col);
diffall_col=24;
data=[data diffall];
%drop outliers of hhincome
%index=find(data(:,hhincome_col)>5000000);
%data(index,:)=[];
index=find(data(:,hhincome_col)==9999999);
data(index,:)=[];
index=find(data(:,hhincome_col)<0);
data(index,:)=[];

%replace some dummies
index=find(data(:,educ_col)<7 & data(:,educ_col)~=1);
data(index,educ_col)=0;
index=find(data(:,educ_col)>6 | data(:,educ_col)==1);
data(index,educ_col)=1;

%=1 is merried with spouse present, if it is different spouse is not present
index=find(data(:,marst_col)~=1);
data(index,marst_col)=0;

index=find(data(:,empstat_col)~=1);
data(index,empstat_col)=0;

index=find(data(:,race_col)~=1 | data(:,hispanic_col)~=0);
data(index,race_col)=0;

%%%%%%%%%%%%
%select the variables
eval(['variables_interests=' variables_interests]);
%%%
min_region=min(data(:,regionid_col));
max_region=max(data(:,regionid_col));
n_regions=max_region-min_region+1;
data_original=data;

demogr=NaN(length(all_years_selected)*n_regions,ns*length(variables_interests));
demogr_means=NaN(length(all_years_selected)*n_regions,ns*length(variables_interests));
demogr_std=NaN(length(all_years_selected)*n_regions,ns*length(variables_interests));
demogr_iqr=NaN(length(all_years_selected)*n_regions,ns*length(variables_interests));
demogr_year_region_id=NaN(length(all_years_selected)*n_regions,1);
for year_counter=1:length(all_years_selected)
    year_selected=all_years_selected(year_counter);
    data=data_original;
    %%%%%%%%%%%%
    index=find(data(:,year_col)~=year_selected);
    data(index,:)=[];

    
    for i=min_region:max_region
        i
        demogr_year_region_id( (year_counter-1)*n_regions+i,1)=year_selected;
        demogr_year_region_id( (year_counter-1)*n_regions+i,2)=i;
        %select obervations
        index=find(data(:,regionid_col)==i);
        data_selected=data(index,:);
        %normalize weights
        data_selected(:,weight_col)=data_selected(:,weight_col)/sum(data_selected(:,weight_col));
        %create some summary statistics of characteristics
        %sample
        cumsum_weights=cumsum(data_selected(:,1));
        
        index=rand([ns,1]);
        positions=NaN(length(index),1);
        for ii=1:length(index)
            positions(ii)=sum(cumsum_weights<=index(ii))+1;
        end
        data_market=data_selected(positions,:);
        %NOTE: variables are de-meaned
        for iii=1:length(variables_interests)
            demogr( (year_counter-1)*n_regions+i, ((iii-1)*ns+1) : (iii*ns) )=data_market(:,variables_interests(iii))'-mean(data_market(:,variables_interests(iii)));
            %demogr( (year_counter-1)*n_regions+i, ((iii-1)*ns+1) : (iii*ns) )=data_market(:,variables_interests(iii))'-min(data_market(:,variables_interests(iii)));
            %demogr( (year_counter-1)*n_regions+i, ((iii-1)*ns+1) : (iii*ns) )=data_market(:,variables_interests(iii));
            demogr_means( (year_counter-1)*n_regions+i, ((iii-1)*ns+1) : (iii*ns) )=mean(data_market(:,variables_interests(iii)));
            demogr_std( (year_counter-1)*n_regions+i, ((iii-1)*ns+1) : (iii*ns) )=std(data_market(:,variables_interests(iii)));
            demogr_iqr( (year_counter-1)*n_regions+i, ((iii-1)*ns+1) : (iii*ns) )=iqr(data_market(:,variables_interests(iii)));
        end
    end

end

%v=randn(size(demogr,1),size(demogr,2)/length(variables_interests));
%v=randn(size(demogr,1),size(demogr,2));

% VERY IMPORTANT: Set below the number of characteristics that will
% interact with the demographics. Right now just 1
v=randn(size(demogr,1),ns*2); %number of plans characteristics interacted * n consumers

% change June 2014, put to sleep line 148 above and switch to lognormal:
%mu=1;
%sigma=.001;
%v = lognrnd(mu,sigma,size(demogr,1),ns*2);
%hist(v)

%v=zeros(size(v));
%demogr=zeros(size(demogr)); 
%demogr_means=zeros(size(demogr_means)); 
%demogr_std=zeros(size(demogr_std)); 
%demogr_iqr=zeros(size(demogr_iqr));

% change August 2014: The following fix is needed for the MPEC, so I used it for NFP as well. 3 individuals affected. 
[rows,cols,vals] = find(demogr>500000);
demogr(rows,cols) = (500000)*ones(size(rows,1),size(cols,1));



save demographics_medicare demogr demogr_means demogr_std demogr_iqr ns demogr_year_region_id

save random_demographics_medicare v