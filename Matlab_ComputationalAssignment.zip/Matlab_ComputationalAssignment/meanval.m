function f = meanval(theta2)
	% This function computes the mean utility level


global theti thetj x2 s_jt mtol %CQ: I removed the silent from global var
load mvalold % loads mvalold oldt2

if max(abs(theta2-oldt2)) < 0.01
	tol = mtol;
    flag = 0;
else
  	tol = mtol;
    flag = 1;
end

theta2w = full(sparse(theti,thetj,theta2));
expmu = exp(mufunc(x2,theta2w));
norm = 1;
avgnorm = 1;

i = 0;
while norm > tol && i < 2501
% while norm > tol *10^(flag*floor(ui/50)) && avgnorm > 1e-3*tol*10^(flag*floor(i/50)) 
   % the following two lines are equivalent; however, the latter saves on the number of exponents
   % computed at therefore speeds up the computation by 5-10%
   %  mval = mvalold + log(s_jt) - log(mktsh(mvalold,expmu));
		mval = mvalold.*s_jt./mktsh(mvalold,expmu); 
    
        t = abs(mval-mvalold);
		norm = max(t);
        avgnorm = mean(t);
  		mvalold = mval;
      i = i + 1;
      if norm > tol && i > 2500
          disp('Max number of 2500 iterations reached')
      end
end
disp(['# of iterations for delta convergence:  ' num2str(i)])
	%what is converging here is norm and avgnorm, as indicated by the "while" command

if flag == 1 && sum(isnan(mval))==0
   mvalold = mval;
   oldt2 = theta2;
   save mvalold mvalold oldt2
end   
f = log(mval);
