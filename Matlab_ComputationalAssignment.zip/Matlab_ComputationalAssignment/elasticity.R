############-----------------Computes elasticity-----------------############
# Inputs: data_elasticity.dta, logit.csv

# change wd
wd <- "/Users/jinchuqing/Dropbox/Empirical IO 2/BU2017/Assigment/";
setwd(wd)

# load packages
require(foreign);
require(xtable);
require(ggplot2);
require(dplyr);


# load logit result from stata: logit.csv
result <- read.csv(file = 'logit.csv', skip = 1, colClasses = c('character',rep('numeric',6)));
result <- result[, -c(4,5)];
names(result) <- c('x', 'logit.ols', 'logit.iv', 'nested.ols', 'nested.iv');

# load market share data: data_elasticity.dta
data <- read.dta(file = 'data_elasticity.dta')
data <- tbl_df(data);
# create the tables for logit
year <- unique(data$year);
region <- unique(data$regionid);

# sample the market
set.seed(7)
sample.year <- sample(year, 1);
sample.region <- sample(region, 1);

# sample the product
data <- ungroup(data %>% group_by(Contract_ID, Plan_ID) %>% mutate(nmkt = sum(!is.na(si))));

elasticity <- function(y, r, model = 'logit.ols', N = 10, product = NA){
  sample.data <- data %>% filter(year == y & regionid == r) %>% arrange(desc(nmkt));
  # select the N products that do not have NA prices and are present in the most markets
  if (is.na(product)){
    nr <- nrow(na.omit(sample.data));
    print(nr)
    # this line uses the 5 most widespread the 5 least widespread
    sample.data <- slice(na.omit(sample.data), c(1:floor(N/2), (nr - N + 1 + floor(N/2)):nr)) %>% arrange(basic);
    # this line uses the 10 most widespread
    # sample.data <- slice(na.omit(sample.data), 1:N);
    product <- as.data.frame(select(sample.data, Contract_ID, Plan_ID, basic));
  }else{
    sample.data <- left_join(product, sample.data) %>% arrange(basic);
  }
  print(nrow(sample.data))
  # calculate elasticity
  alpha <- result[1, model];
  if (model %in% c('logit.ols', 'logit.iv')){
  elasticity <- matrix(rep(-alpha * sample.data$si * sample.data$Part_D_Total_Premium, nrow(sample.data)), 
                       byrow = FALSE, ncol = nrow(sample.data));
  diag(elasticity) <- alpha * sample.data$Part_D_Total_Premium - diag(elasticity);
  }else if (model %in% c('nested.ols', 'nested.iv')){
    sigma <- result[7, model];
    elasticity <- -alpha * outer(sample.data$si, sample.data$si);
    samegroup <- outer(sample.data$basic, sample.data$basic, FUN = "==");
    elasticity <- elasticity  - samegroup * alpha * sigma / (1-sigma) * outer(sample.data$sg, sample.data$si);
    diag(elasticity) <- alpha/(1-sigma) * sample.data$si - diag(elasticity);
  }else{
    warning('The model must be one of the followign: logit.ols, logit.iv, nested.ols, nested.iv.');
    return(NA);
  }
  return(list(elasticity, product))
}

# pick one market as an example and illustrate 
make_e_table <- function(elas){
  rname <- apply(elas[[2]][-3], MARGIN = 1, function(i) paste(i[1], i[2], sep = "_"));
  tab <- elas[[1]]*1e08;
  colnames(tab) <- rname;
  rname[1:5] <- paste('\rowcolor{white}', rname[1:5], sep = '');
  rownames(tab) <- rname;
  
  # basic <- as.logical(unlist(elas[[2]][3]));
  # color <- paste('\textcolor{blue}{', tab[basic, basic], '}', sep = '');
  # tab[basic,basic] <- matrix(color, byrow = FALSE, ncol = sum(basic));
  # rm(color, basic)
  return(tab)
}

m <- names(result)[-1];
a <- lapply(m, function(i) elasticity(y = 2012, r = 7, model = i));
tab <- lapply(a, make_e_table)
xres <- lapply(tab, function(i) xtable(i, digits = c(NA, rep(2, ncol(i)))));


# a numerical method to compare logit and nested logit 
# run a regression of all elasticities, using a dummy for own elasticity, a dummy for within group elasticity, interract with a dummy for nested logit
# only consider the model with iv
count <- as.data.frame(data %>% group_by(year, regionid) %>% summarize(sum(!is.na(si))));
all.logit <- lapply(1:nrow(count), function(i) elasticity(y = count[i,1], r = count[i,2], model = 'logit.iv', N = count[i,3]));
all.nested <- lapply(1:nrow(count), function(i) elasticity(y = count[i,1], r = count[i,2], model = 'nested.iv', N = count[i,3]));
# turn the lists into columns 
transform <- function(elas){
  N <- nrow(elas[[1]]);
  N <- N*N;
  output <- data.frame(elasticity = rep(NA, N), iforshare = rep(NA, N), jforprice = rep(NA, N),
                       gi = rep(NA, N), gj = rep(NA, N));
  N <- sqrt(N);
  product.name <- apply(elas[[2]], 1, function(i) paste(i[1], i[2], sep = '_'));
  output$elasticity <- as.numeric(elas[[1]]);
  output$iforshare <- as.vector(matrix(product.name, nrow = N, ncol = N, byrow = TRUE));
  output$jforprice <- as.vector(matrix(product.name, nrow = N, ncol = N, byrow = FALSE));
  output$gi <- as.numeric(matrix(elas[[2]][[3]], nrow = N, ncol = N, byrow = TRUE));
  output$gj <- as.numeric(matrix(elas[[2]][[3]], nrow = N, ncol = N, byrow = FALSE));
  output$own <- output$iforshare == output$jforprice;
  output$sameg <- output$gi == output$gj;
  return(output)
}
stack.all.logit <- lapply(all.logit, transform);
stack.all.logit <- rbindlist(stack.all.logit);
stack.all.logit$nested<- FALSE;
stack.all.nested <- lapply(all.nested, transform);
stack.all.nested <- rbindlist(stack.all.nested);
stack.all.nested$nested <- TRUE;
stack.all <- rbindlist(list(stack.all.logit, stack.all.nested));

save.image()
fit1 <- lm(elasticity * 10000 ~ own + sameg, data = stack.all.logit);
fit2 <- lm(elasticity * 10000 ~ own + sameg, data = stack.all.nested);
stargazer(fit1, fit2, type = 'text')
stargazer(fit1, fit2)
