vim
input.dataFormat = {'%.3f',1,'(%.3f)',1,'%.3f',1,'(%.3f)',1,'%.3f',1,'(%.3f)',1};
input.tableColLabels = {'Original','','With \# medication','','Modified IV',''};
%input.tableRowLabels = 
input.data = [[theta2';theta1(1:2);NaN;theta1(3:end);fval], [se([end-2:end, 1:2]);NaN;se(3:end-3);NaN]];
input.dataNanString = '';
input.tableCaption = 'BLP Estimates';
input.tableLabel = 'tab:blp';

save input input
clear 
load input
load myBLP_results_5e-16_search_nmedication.mat
input.data = [input.data,[theta2';theta1;fval], [se([end-2:end, 1:end-3]);NaN]];

save input input
clear 
load input
load myBLP_results_5e-16_search_newIV.mat
input.data = [input.data,[theta2';theta1(1:2);NaN;theta1(3:end);fval], [se([end-2:end, 1:2]);NaN;se(3:end-3);NaN]];
latexTable(input);

