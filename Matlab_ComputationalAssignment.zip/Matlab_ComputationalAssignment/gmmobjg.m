  function [f,df] = gmmobjg(theta2)
	% This function computes the GMM objective function. f is the objective, and df is the gradient.
    % To compute f, we need to have the delta. Delta is obtained by
    % invoking the function "meaneval" which computes the mean utility,
    % delta, starting from known theta2



global invA theta1 theti thetj x1 IV

delta = meanval(theta2);

% the following deals with cases were the min algorithm drifts into region where the objective is not defined
if max(isnan(delta)) == 1
	f = 1e+10;
else
    temp1 = x1'*IV;
    temp2 = delta'*IV;
    theta1 = inv(temp1*invA*temp1')*temp1*invA*temp2';
    %theta1 = pinv(temp1*invA*temp1')*temp1*invA*temp2';
    clear temp1 temp2
    gmmresid = delta - x1*theta1;
	temp1 = gmmresid'*IV;
	f1 = temp1*invA*temp1';
    f = f1;
    clear temp1
    if nargout>1
        load mvalold
        temp = jacob_medicare(mvalold,theta2)';
        df = 2*temp*IV*invA*IV'*gmmresid; 
    end
end

disp(['GMM objective:  ' num2str(f)])

 save gmmresid; 
	%gmmresid.mat is needed later by the subroutine var_cov.m





