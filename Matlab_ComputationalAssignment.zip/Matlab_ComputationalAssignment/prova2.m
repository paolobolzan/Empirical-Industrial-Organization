
load BLP_results.mat

%

%%%%%%GROUP A

control_groupA=find(data(:,groupA_col)==0);
treatment_groupA=find(data(:,groupA_col)==99);



%xA_control=[ones(size(data(control_groupA,:),1),1) data(control_groupA,[ deductible_col drug_frf_col d_cov_gap_col d_enhance_col tier_12_col top_drug_col in_area_flag_col vintage_col  ]) ];%
xA_control=[ones(size(data(control_groupA,:),1),1) data(control_groupA,[ deductible_col drug_frf_col d_cov_gap_col d_enhance_col tier_12_col top_drug_col in_area_flag_col vintage_col dummy_firm_start:dummy_firm_end dummy_year_start+2:dummy_year_end dummy_region_start+1:dummy_region_end ]) unobservable_component(control_groupA)];%
index_drop=find(sum(xA_control)==0);
index_drop=[1 index_drop];
xA_control(:,index_drop)=[];
% 
yA_control=mc(control_groupA);                                           

%xA_treat=[ones(size(data(treatment_groupA,:),1),1) data(treatment_groupA,[ deductible_col drug_frf_col d_cov_gap_col d_enhance_col tier_12_col top_drug_col in_area_flag_col vintage_col ])];%
xA_treat=[ones(size(data(treatment_groupA,:),1),1) data(treatment_groupA,[ deductible_col drug_frf_col d_cov_gap_col d_enhance_col tier_12_col top_drug_col in_area_flag_col vintage_col dummy_firm_start:dummy_firm_end dummy_year_start+2:dummy_year_end dummy_region_start+1:dummy_region_end]) unobservable_component(treatment_groupA)];%
xA_treat(:,index_drop)=[];
yA_treat=mc(treatment_groupA);

%the last variable is equal to 1 for control, 0 for treatment and 99 for all other
indicator_groupA=99*ones(size(data,1),1);
indicator_groupA(control_groupA)=1;
indicator_groupA(treatment_groupA)=0;
%%%%%%%%%%

beta_control=inv(xA_control'*xA_control)*xA_control'*yA_control;
beta_control_final=[beta_control];
error_control=yA_control-xA_control*beta_control;
var_cov_beta=(inv(xA_control'*xA_control)*xA_control'*error_control)*(inv(xA_control'*xA_control)*xA_control'*error_control)';

std_regressors=std(xA_control);
std_error=std(yA_control'-beta_control'*xA_control');

std_beta=(std_error./std_regressors)';
%std_beta=std_error^2*(beta_control*beta_control')^-1;

yA_treat_predicted=xA_treat*beta_control;

error_predict=yA_treat_predicted-yA_treat;
mean(error_predict);
sum(error_predict<0)/length(error_predict);

x_matrix=[ones(size(data,1),1) data(:,[  deductible_col drug_frf_col d_cov_gap_col d_enhance_col tier_12_col top_drug_col in_area_flag_col vintage_col dummy_firm_start:dummy_firm_end dummy_year_start+2:dummy_year_end dummy_region_start+1:dummy_region_end ]) unobservable_component];
x_matrix(:,index_drop)=[];
mc_predicted=x_matrix*beta_control;

prices_predicted=[];
old_index=0;
for i=1:length(cdindex)
    index=(old_index+1):cdindex(i);
    prices_predicted=[prices_predicted ; (ownership_matrix(index,index).*-omega_matrix(index,index).*kron(data(index,market_sizes_col),ones(1,length(index)))+(kron(1-data(index,indicator_bench_col),ones(1,length(index)))).*ownership_matrix(index,index).*-omega_matrix_lischoosers(index,index).*kron(data(index,tot_lis_choosers_col),ones(1,length(index))))^(-1)...
        *(s_jt(index).*data(index,market_sizes_col)+(1-data(index,indicator_bench_col)).*data(index,ms_lischoosers_col).*data(index,tot_lis_choosers_col)+data(index,indicator_bench_col).*data(index,ms_lis_col).*data(index,tot_lis_col))+mc_predicted(index)];
    %prices_predicted=[prices_predicted ; (omega_matrix(index,index)+(kron(data(index,indicator_bench_col),ones(1,length(index)))).*omega_matrix_lischoosers(index,index))^(-1)*(s_jt(index).*data(index,market_sizes_col)+(ones(length(index),1)-data(index,indicator_bench_col)).*data(index,ms_lischoosers_col).*data(index,tot_lis_choosers_col))+mc_predicted(index)];
    old_index=cdindex(i);
end

median(prices(control_groupA)-prices_predicted(control_groupA));
mean(prices(treatment_groupA)-prices_predicted(treatment_groupA));
median(prices(treatment_groupA)-prices_predicted(treatment_groupA));

overpricing_control=prices(control_groupA)-prices_predicted(control_groupA);
% subplot(1,2,1), hist(prices(control_groupA))
% title(['Control - observed'])
% mean(overpricing_control./prices(control_groupA))
% overpricing_treatment=prices(treatment_groupA)-prices_predicted(treatment_groupA);
% subplot(1,2,2), hist(prices_predicted(control_groupA))
% title(['Control - predicted'])
% xlim([0 50])
% mean(overpricing_treatment./prices(treatment_groupA))

mc_groupAnew=mc_predicted;
beta_controlnew=beta_control;
%hist(error_predict,100)
%title(['Group A'],'FontSize',18)
%saveas(gcf,'groupA','pdf')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%

%%%%%%GROUP A

control_groupA=find(data(:,groupA_col)==0);
treatment_groupA=find(data(:,groupA_col)==99);



%xA_control=[ones(size(data(control_groupA,:),1),1) data(control_groupA,[ deductible_col drug_frf_col d_cov_gap_col d_enhance_col tier_12_col top_drug_col in_area_flag_col vintage_col  ]) ];%
xA_control=[ones(size(data(control_groupA,:),1),1) data(control_groupA,[ deductible_col drug_frf_col d_cov_gap_col d_enhance_col tier_12_col top_drug_col in_area_flag_col vintage_col ]) unobservable_component(control_groupA)];%
index_drop=find(sum(xA_control)==0);
index_drop=[1 index_drop];
xA_control(:,index_drop)=[];
% 
yA_control=mc(control_groupA);                                           

%xA_treat=[ones(size(data(treatment_groupA,:),1),1) data(treatment_groupA,[ deductible_col drug_frf_col d_cov_gap_col d_enhance_col tier_12_col top_drug_col in_area_flag_col vintage_col ])];%
xA_treat=[ones(size(data(treatment_groupA,:),1),1) data(treatment_groupA,[ deductible_col drug_frf_col d_cov_gap_col d_enhance_col tier_12_col top_drug_col in_area_flag_col vintage_col]) unobservable_component(treatment_groupA)];%
xA_treat(:,index_drop)=[];
yA_treat=mc(treatment_groupA);

%the last variable is equal to 1 for control, 0 for treatment and 99 for all other
indicator_groupA=99*ones(size(data,1),1);
indicator_groupA(control_groupA)=1;
indicator_groupA(treatment_groupA)=0;
%%%%%%%%%%

beta_control=inv(xA_control'*xA_control)*xA_control'*yA_control;
beta_control_final=[beta_control];
error_control=yA_control-xA_control*beta_control;
var_cov_beta=(inv(xA_control'*xA_control)*xA_control'*error_control)*(inv(xA_control'*xA_control)*xA_control'*error_control)';

std_regressors=std(xA_control);
std_error=std(yA_control'-beta_control'*xA_control');

std_beta=(std_error./std_regressors)';
%std_beta=std_error^2*(beta_control*beta_control')^-1;

yA_treat_predicted=xA_treat*beta_control;

error_predict=yA_treat_predicted-yA_treat;
mean(error_predict);
sum(error_predict<0)/length(error_predict);

x_matrix=[ones(size(data,1),1) data(:,[  deductible_col drug_frf_col d_cov_gap_col d_enhance_col tier_12_col top_drug_col in_area_flag_col vintage_col]) unobservable_component];
x_matrix(:,index_drop)=[];
mc_predicted=x_matrix*beta_control;

prices_predicted=[];
old_index=0;
for i=1:length(cdindex)
    index=(old_index+1):cdindex(i);
    prices_predicted=[prices_predicted ; (ownership_matrix(index,index).*-omega_matrix(index,index).*kron(data(index,market_sizes_col),ones(1,length(index)))+(kron(1-data(index,indicator_bench_col),ones(1,length(index)))).*ownership_matrix(index,index).*-omega_matrix_lischoosers(index,index).*kron(data(index,tot_lis_choosers_col),ones(1,length(index))))^(-1)...
        *(s_jt(index).*data(index,market_sizes_col)+(1-data(index,indicator_bench_col)).*data(index,ms_lischoosers_col).*data(index,tot_lis_choosers_col)+data(index,indicator_bench_col).*data(index,ms_lis_col).*data(index,tot_lis_col))+mc_predicted(index)];
    %prices_predicted=[prices_predicted ; (omega_matrix(index,index)+(kron(data(index,indicator_bench_col),ones(1,length(index)))).*omega_matrix_lischoosers(index,index))^(-1)*(s_jt(index).*data(index,market_sizes_col)+(ones(length(index),1)-data(index,indicator_bench_col)).*data(index,ms_lischoosers_col).*data(index,tot_lis_choosers_col))+mc_predicted(index)];
    old_index=cdindex(i);
end

median(prices(control_groupA)-prices_predicted(control_groupA));
mean(prices(treatment_groupA)-prices_predicted(treatment_groupA));
median(prices(treatment_groupA)-prices_predicted(treatment_groupA));

overpricing_control=prices(control_groupA)-prices_predicted(control_groupA);
% subplot(1,2,1), hist(prices(control_groupA))
% title(['Control - observed'])
% mean(overpricing_control./prices(control_groupA))
% overpricing_treatment=prices(treatment_groupA)-prices_predicted(treatment_groupA);
% subplot(1,2,2), hist(prices_predicted(control_groupA))
% title(['Control - predicted'])
% xlim([0 50])
% mean(overpricing_treatment./prices(treatment_groupA))

mc_groupAold=mc_predicted;
beta_controlold=beta_control;

%hist(error_predict,100)
%title(['Group A'],'FontSize',18)
%saveas(gcf,'groupA','pdf')


subplot(2,1,1), hist(yA_control,100)
xlim([50 200])
subplot(2,1,2), hist(mc_groupAold,100)
xlim([50 200])