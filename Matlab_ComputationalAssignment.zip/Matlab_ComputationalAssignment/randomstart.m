clear 
clc

global theta2w mtol istart startvalues

mtol = 1e-12;
n = 5;
startvalues = [1, -1;
               1, -0.5;
               2, -1;
               0.5, -1;
               1, -1];
           
for istart = 1:n
    theta2w = startvalues(istart,:);
    save trackstart theta2w mtol istart startvalues
    %enter the name of your matlab code here;
end
