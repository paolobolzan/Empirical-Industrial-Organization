function f = mktsh_basic(mval,expmu,youth)
% This function computes the market share for each pdp=1 product seperatly  
% for people who are above and bellow 75yrs old

global ns cdid_demogr x1


load('demographics_medicare.mat');

enhanced = x1(:,6)*100;
cdid_demogr_enhanced=cdid_demogr(find(enhanced==0));



%create matrix [year region] sorted year then region of length year*region
yrs = [2007:2010];
mrkt= [1:34];
market_year = [repmat(mrkt,1,4); reshape(repmat(yrs,34,1),1,[])]';

%Fix:
age = demogr(:,ns+1:2*ns) + demogr_means(:,ns+1:2*ns);
%age = demogr(:,ns+1:2*ns);
market_year_resort = [market_year age];
market_year_resort = sortrows(market_year_resort,[1 2]);
age = market_year_resort(:,2:end);

market_year_resort = market_year_resort(cdid_demogr_enhanced,2);
age = age(cdid_demogr_enhanced,:);
age = age(find(age(:,1)~=2010),2:end);
ind = ind_sh(mval,expmu);
ind = ind(find(enhanced==0),:);
ind = [market_year_resort ind];
ind = ind(find(ind(:,1)~=2010),2:end);


market = unique(cdid_demogr_enhanced(find(market_year_resort~=2010)));

if youth == 0

mkt = nan(size(ind,1),1);
for j=1:size(ind,1) %each enhanced product in each market
    mkt(j) = sum(ind(j,find(age(j,:)>=75)),2)/max(size(ind(j,find(age(j,:)>=75)),2),1); %sum of prob of purchase for 75+/# of 75+
end

prob_p_old = nan(size(market,1),1);
for j=1:size(market)
    index = find(cdid_demogr_enhanced(find(market_year_resort~=2010))==market(j));
    prob_p_old(j) = sum(mkt(index));
    if prob_p_old(j)==nan
        prob_p_old(j)=0;
    end
end

  f = prob_p_old;

  elseif youth == 1   
      
mkt_young = nan(size(ind,1),1);
for j=1:size(ind,1) %each product in each market
    mkt_young(j) = sum(ind(j,find(age(j,:)<75)),2)/max(size(ind(j,find(age(j,:)<75)),2),1); %sum of prob of purchase for >75 /# of >75
end

prob_p_young = nan(size(market,1),1);
for j=1:size(market)
    index = find(cdid_demogr_enhanced(find(market_year_resort~=2010))==market(j));
    prob_p_young(j) = sum(mkt_young(index));
     if prob_p_young(j)==nan
        prob_p_young(j)=0;
    end
end


  
 
    f = prob_p_young;
end

f = f';


