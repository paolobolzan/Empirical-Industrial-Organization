clear 
clear global 
clc

input.dataFormat = {'%.3f',8};
input.tableColLabels = {'Original','Newton_5e-16_1','Newton_5e-16_2','Newton_5e-16_3','Newton_5e-16_4', 
    'Newton_5e-16_5','Newton_1e-16_1','Newton_1e-14_1'};
%input.tableRowLabels = {
input.dataNanString = '';
input.tableCaption = 'BLP Estimates with Alternative Starting Values and Tolerance Levels';
input.tableLabel = 'tab:blpdiagnostics';

load myBLP_results_5e-16_search_original.mat
input.data = [theta2';theta1;gmmobjg(theta2)'];

tolerance = [5e-16, 5e-16, 5e-16, 5e-16, 5e-16, 1e-16, 1e-14];
startvalueid = [1:5,1,1];

for i = 1:7
load(sprintf('myBLP_results_%.0e_newton_%.0e.mat',tolerance(i),startvalueid(i)));
%sprintf('myBLP_results_%.0e_newton_%.0e.mat',tolerance(i),startvalueid(i))
input.data = [input.data,[theta2';theta1;gmmobjg(theta2)']];
end

save input2.2 input
clear 
load input
latexTable(input);

