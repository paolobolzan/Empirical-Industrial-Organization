%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 0. RClogit_OptimalInstruments.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This file shows how to implement optimal instruments in the random
% coefficient logit model with a small example. The example illustrates  
% the findings of Mathias Reynaert and Frank Verboven (2013) "Improving the 
% performance of random coefficient demand models: The role of optimal 
% instruments" Journal of Econometrics.

% Please note that this file is a simple illustration with a simulated data
% set. When applying the RC logit model with real data we recommend to 
% check carefully for local minima and other computational pitfalls. A 
% comprehensive checklist can be found in Goldberg an Hellerstein (2013).

% Input: DATASET.mat
% Output: Table with estimates for a standard and an optimal instrument set

% 1. Load Data
% 2. Data Structure, Individual Tastes and Instruments
% 3. Linear Estimation To Get Starting Values
% 4. Stage 1: Estimation with Standard Instrument Set
% 5. Computation of Optimal Instruments
% 6. Stage 2: Estimation with Optimal Instrument
% 7. Results 

% Original code written by Mathias Reynaert (2013)
% Modified by Chuqing Jin for EC733 project at BU

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% 1. Load Data
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% clear;
% % Data contains exogenous variables in matrix A, cost shifter z and
% % endogenous prices p and market shares
% 
% % Size of the dataset
% % nmkt = 25;                   % number of markets = (# of cities)*(# of quarters)  
% % nbrn = 10;                   % number of brands per market
% % nobs=nmkt*nbrn;              % number of observations 
% % cdid = kron((1:nmkt)',ones(nbrn,1)); % vector with marketnumber for each obs
% % cdindex = (nbrn:nbrn:nbrn*nmkt)';    % vector with last obs per market 4-8-12
% 
% load DATASET_global
% global mtol
% disp(['The contraction mapping precision is     ', num2str(mtol)]);
% A = x1;
% A(:,2) = [];
% price = x2;
% share = s_jt;
% dummarket=dummyvar(cdid);            % dummies for each market
% nobs = size(A,1);
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% 2. Data Structure, Individual Tastes and Instruments
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Structure of Estimation
% Xexo=[A price];
% Xrandom=price; % we place random coefficients on price (all based on demography)
% logobsshare=log(share);
% 
% % Number of parameters
% nlin = size(Xexo,2);            % number of linear parameters
% nrc = size(Xrandom,2);            % number of characteristics with random coefficients
% j = size(dfull,2)/ns;           % number of demographics
% %ninst = size(z,2);              % number of cost shifters
% 
% % Individual Tastes
% % Individual tastes are the same as those used in simulation. Here we use
% % very crude pseudo Monte Carlo Integration. In applications we recommend
% % to work with other appoximations of the market share integrals such as
% % Halton draws of Sparse Grids. (note: changing the seed or number of draws
% % makes no sense here since we did not simulate the data with an 'infinite'
% % amount of draws)
% % rng(6)
% % ndraws=500;
% % v=randn(nobs,ndraws*nrc);
% ndraws = ns;
% v = [vfull(:,1:ndraws*nrc), dfull(:, 1:ndraws*j*nrc)];
% xv=zeros(nobs,ndraws*nrc*(1+j));
% for i = 1:nrc
%     xv(:,(i-1)*(1+j)*ndraws+1:i*(1+j)*ndraws)=bsxfun(@times,Xrandom(:,i),v(:,[(i-1)*ndraws+1:i*ndraws,ndraws*nrc+(i-1)*ndraws*j+1:ndraws*nrc+i*ndraws*j]));
% end
% 
% % Data that we will use in the different functions
% Data.drawsintegration=1; % this option is set to 1 because we do not use weights for the integral
% % Data.nmkt=nmkt;
% % Data.nbrn=nbrn;
% Data.cdid=cdid;
% Data.dummarket=dummarket;
% Data.nrc=nrc;
% Data.nlin=nlin;
% Data.ndraws=ndraws;
% Data.logobsshare=logobsshare;
% Data.share=share;
% Data.xv=xv;
% Data.nobs=nobs;
% Data.Xrandom=Xrandom;
% Data.Xexo = Xexo;
% 
% Data.j = j;
% 
% % Instrument Set for the First Stage
% % Z=[A z bsxfun(@times,price,z) z.^2];
% Data.Z = Z;
% 
% % Weighting Matrix for the First Stage
% norm=mean(mean(Z'*Z),2);
% W=inv((Z'*Z)/norm)/norm;
% % Some Data that speeds up computations
% xzwz=Xexo'*Z*W*Z';
% Data.xzwz=xzwz;
% xzwzx=xzwz*Xexo;
% locnorm=mean(mean(xzwzx),2);
% Data.invxzwzx=inv(xzwzx/locnorm)/locnorm;
% Data.W = W;
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% 3. Linear Estimation To Get Starting Values
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %TSLS
% %STAGE I: INITIAL WEIGHTING MATRIX*/
% % ou=1-share;
% temp = cumsum(share);
% sum1 = temp(cdindex,:);
% sum1(2:size(sum1,1),:) = diff(sum1);
% ou = 1.0 - sum1(cdid,:);
% ou = abs(ou);
% disp(['Object temp dimensions: ' num2str(size(temp)) ])
% disp(['Object sum1 dimensions: ' num2str(size(sum1)) ])
% disp(['Object outshr dimensions: ' num2str(size(ou)) ])
% 
% % INITIAL WEIGHTING MATRIX IS FROM A LOGIT MODEL WITH INSTRUMENTS (P5/87 IN
% % THE PAPER)
% y=log(share)-log(ou);
% mid=Z*W*Z';
% btsls=(Xexo'*mid*Xexo)\(Xexo'*mid*y);
% xi=y-Xexo*btsls;
% sst=inv(Xexo'*mid*Xexo);
% dgf=(size(Xexo,1)-size(Xexo,2));
% ser=(xi'*xi)./dgf;
% setsls=sqrt(ser*diag(sst));
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% 4. Stage 1: Estimation with Standard Instrument Set
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%% OPTIMIZATION
% delta0=zeros(nobs,1);
% save mvaloldoptiv delta0
% 
% % Pass Data into gmm using anonymous functions
% % theta20=btsls(end,1)./2; 
% theta20 = [1;-1;1];
% angmm = @(theta20)gmm(theta20,Data);
% 
% options = optimset( 'Display','iter',...
%                     'GradObj','on','TolCon',1E-6,...
%                     'TolFun',1E-6,'TolX',1E-6,...
%                     'Hessian', 'off','DerivativeCheck','off');    
% 
% [theta] = fminunc(angmm,theta20, options);
% 
% load bet
% th12fs=[bet; theta];
% se12fs=seblp(th12fs,Data);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 5. Computation of Optimal Instruments 
% CQ completely changed this part. 
% For the original code, go the original code folder
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function f = optiv_medicare(Data)
global x2
%% Unpack!
% I need:
% first stage theta result as starting values 
theta20 = Data.theta2;
theta10 = Data.theta1;
% instruments
Z = Data.IV;
% price
price = Data.x2;
endoindex = Data.endoindex;
% x1 less price (to calculate the delta)
Xexo =  Data.x1;
clear Data

%% Two Stage Least Squares Estimation of Price
Xendohat=Z*((Z'*Z)\(Z'*Xexo(:,endoindex)));
phat = Xendohat(:,2);
Xhat = Xexo;
Xhat(:,endoindex) = Xendohat;

%Compute Delta at First Stage estimates
delta1 = Xhat*theta10;

%Compute Jacobion of mean utilities at First Stage estimates to get the
%optimal instrument for the nonlinear parameters
%change x2 before calculating jacobian
x2 = phat;
chamberlin=jacob_medicare(delta1,theta20);
x2 = price;

% Form the Optimal Instrument Set such that #instruments=#parameters
Zopt=[Xhat chamberlin];

f = Zopt;
end
% % Weighting Matrix (might as well be Identity Matrix because of just
% % identified)
% norm=mean(mean(Z'*Z),2);
% W=inv((Z'*Z)/norm)/norm;
% % Some Data that speeds up computations
% xzwz=Xexo'*Z*W*Z';
% Data.xzwz=xzwz;
% xzwzx=xzwz*Xexo;
% locnorm=mean(mean(xzwzx),2);
% Data.invxzwzx=inv(xzwzx/locnorm)/locnorm;
%  
% Data.Z = Z;
% Data.W = W;
% Data.Xrandom=Xrandom;
% Data.Xexo = Xexo;
% 
% % EXTENSION: Random Coefficients on Endogenous Variables
% 
% % In this exercise we placed a random coefficient on one exogenous
% % variable. The taste for an endogenous variable (price) could also vary
% % in the population. When computing optimal instruments we need to make 
% % sure that the chamberlain type of instrument is not 'contaminated' by the 
% % endogenous price variable. Therefore we need to use the nonlinear 
% % part at the predicted prices in the computations. This can be done as
% % follows:
% 
% % xvhat=zeros(nobs,nrc*ndraws);
% % Xrandomhat=[A(:,2) phat];
% % for i = 1:nrc
% %      xvhat(:,(i-1)*ndraws+1:(i)*ndraws)=bsxfun(@times,Xrandomhat(:,i),v(:,(i-1)*ndraws+1:(i)*ndraws));
% % end
% % data.xv=xvhat;
% % delta1=[Xexo(:,1:end-1) phat]*theta10;
% % chamberlin=jacob(theta20,delta1,data);
% % % Then we replace the nonlinear part again for the remainder of the 
% % % procedure: 
% % data.xv=xv;
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% 6. Stage 2: Estimation with Optimal Instrument
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%% OPTIMIZATION
% % Pass Data into gmm using anonymous functions
% angmm = @(theta20)gmm(theta20,Data);
% 
% options = optimset( 'Display','iter',...
%                     'GradObj','on','TolCon',1E-6,...
%                     'TolFun',1E-6,'TolX',1E-6,...
%                     'Hessian', 'off','DerivativeCheck','off');    
% 
% t1 = cputime;
% [theta, fval, exitflag, output, lambda] = ...
% fminunc(angmm,theta20, options);
% load bet
% th12ss=[bet; theta];
% se12ss=seblp(th12ss,Data);
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% 7. Results 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% variables={'x0','x1','p','RC on x1'};
% title1={'Variable','Param.','St.Err.','Param.','St.Err.'};
% truenl=[2,2,-2,1];
% resultt1=[th12fs se12fs th12ss se12ss];
% disp('Results of MPEC with different Instruments')
% disp([title1;variables.',num2cell(resultt1)])


