function [f,df] = gmmobjg_micro(theta2)
	% This function computes the GMM objective function. f is the objective, and df is the gradient.
    % To compute f, we need to have the delta. Delta is obtained by
    % invoking the function "meaneval" which computes the mean utility,
    % delta, starting from known theta2



global invA theta1 theti thetj x1 x2 IV Prob_young Prob_old pop_rich cdid_demogr

delta = meanval(theta2);

%%%%%%%%%%%%%
%mval = meanval(theta2)
%expmu = exp(mufunc(x2,theta2w));
t2w = [theta2([1 2]), theta2([3 4]), theta2([5 6])];
delta_micro=mufunc(x2,t2w);

polde = mktsh_sub(exp(delta),exp(delta_micro),0);
pyounge = mktsh_sub(exp(delta),exp(delta_micro),1);
P_old = (polde./(polde + mktsh_basic(exp(delta),exp(delta_micro),0)))';
P_young = (pyounge./(pyounge + mktsh_basic(exp(delta),exp(delta_micro),1)))';

%%%%%%%%%%%%% USING each as moment
mom = [P_old-Prob_old; P_young-Prob_young];

%%%%%%%%%%%% Using 34*2 region moments 
% index = kron((1:34)',[1 1 1]');
% mom = nan(68,1);
% for i=1:34
%    mom(i) = sum(P_old(find(index==i))-Prob_old(find(index==i)))/3;
%    mom(34+i)= sum(P_young(find(index==i))-Prob_young(find(index==i)))/3;
% end
%%%%%%%%%%%% Using 3*2 year moments
% index = repmat((1:3)', 34,1);
% mom = nan(6,1);
% for i=1:3
%    mom(i) = (sum(P_old(find(index==i))-Prob_old(find(index==i))))/34;
%    mom(3+i) = (sum(P_young(find(index==i))-Prob_young(find(index==i))))/34;
% end

%%%%%%%%%%% Weighting matrix 
invB = 100.*eye(size([mom*mom'],1)); %identity
%invB = inv([mom*mom']); %
Weight = blkdiag(invA,invB);
%%%%%%%%%%%%%%%%%



% the following deals with cases were the min algorithm drifts into region where the objective is not defined
if max(isnan(delta)) == 1
	f = 1e+10;
else
    temp1 = x1'*IV;
    temp2 = delta'*IV;
    theta1 = inv(temp1*invA*temp1')*temp1*invA*temp2';
    %theta1 = pinv(temp1*invA*temp1')*temp1*invA*temp2';
    clear temp1 temp2
    gmmresid = delta - x1*theta1;
	temp1 = gmmresid'*IV;
    temp1 = [temp1 mom'];
	f1 = temp1*Weight*temp1';
    f = f1;
    clear temp1
    if nargout>1
        load mvalold
        temp = jacob_medicare(mvalold,theta2)';
        df = 2*temp*IV*invA*IV'*gmmresid 
    end
end

disp(['GMM objective:  ' num2str(f)])

 save gmmresid; 
	%gmmresid.mat is needed later by the subroutine var_cov.m





