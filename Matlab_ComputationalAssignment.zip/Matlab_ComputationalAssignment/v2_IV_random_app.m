clear
clc

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                    ')

delete mydiary_v2_IV_app.txt %we don't want any old mydiary.txt file to interfere.
diary mydiary_v2_IV_app.txt
date = datestr(clock)

%% Preparation of the dataset

global invA ns x1 x2 s_jt IV vfull dfull theta1 theti thetj cdid cdindex v demogr 
global theta2w istart mtol
load trackstart.mat

load datapp; %import dataset "dataset_computational_noise.csv"
load demograpps; %import dataset "demogr_apps.csv"

%delete variables unnecessary to our analysis
datapp(:,{'app_id','ndownloads','lowerbound','upperbound','ndgenre','inapppurchases','estimateddownloads','highest_rank','lowest_rank'})=[];

%drop rows with no average score
datapp(isnan(datapp.averagescore),:)=[];

%create a unique identifier column for country-year, country-year-nest,
%country-year-genre
datapp.countryyear=strcat(cellstr(datapp.country), '_', num2str(datapp.year));
datapp.countryyearnest=strcat(cellstr(datapp.countryyear), '_', cellstr(datapp.nest));
datapp.countryyeargenre=strcat(cellstr(datapp.countryyear), '_', cellstr(datapp.appgenre));

%generate IV for price as Hausman style instrument built as the average
%price of the same app in all other countries in a given year
datapp.appyear=strcat(cellstr(datapp.app), '_', num2str(datapp.year));
datapp.appyear=string(datapp.appyear);
h=height(datapp)
for i=1:h
    index=datapp.appyear==datapp.appyear(i);
    price_var_i=datapp(index,"price");
    if size(price_var_i,1) > 1
        price_var_i(1,:)=[];
    end
    avg_price=sum(table2array(price_var_i))/height(price_var_i);
    datapp.avgprice(index)=avg_price;
end

%sort table according to country, year & nest
datapp=sortrows(datapp,'countryyearnest');

%calculate the marketshare of each country (market) in each year
sumarray = grpstats(datapp.new_est, datapp.countryyear, @sum);
groupindices = grp2idx(datapp.countryyear);
datapp.DownloadsCountryYear = sumarray(groupindices);

%calculate the marketshare of each app in each country(market) in each year
datapp.mktshare=datapp.new_est./datapp.DownloadsCountryYear;

%calculate the marketshare of each nest in each country (market) in
%each year
sumarray = grpstats(datapp.mktshare, datapp.countryyearnest, @sum);
groupindices = grp2idx(datapp.countryyearnest);
datapp.MktShareCountryYearNest = sumarray(groupindices);

%create a column of number of apps per each genre per country per year
datapp.count=ones(size(datapp,1),1); %create a columns of ones
sumarray = grpstats(datapp.count, datapp.countryyeargenre, @sum);
groupindices = grp2idx(datapp.countryyeargenre);
datapp.CountCountryYearGenre = sumarray(groupindices);

%create a table of all outside marketshares called outside, the outside
%shares will be appended to the original dataset (datapp) in the loop to
%define the cdid
index=ismember(datapp.nest,'OUTSIDE');
outside=datapp.MktShareCountryYearNest(index);
osmark=datapp.countryyearnest(index);
outside=table(outside,osmark);
outside=unique(outside);
outside=sortrows(outside,'osmark');
datapp=datapp(~contains(cellstr(datapp.countryyearnest),'OUTSIDE'),:);



load random_demographics_medicare %import dataset "v.csv"
ns=500
demogr=table2array(demograpps); %transform table into a matrix

%adapt the demographics and the unobservable characteristics to the size of
%our dataset & scale the demographics
demogr=demogr(1:36,:)/1000;
v=v(1:36,:);

% The  vector  below relates each observation to the market it is in &
% appends a column outsideshare, that is equal to the corresponding
% outsideshare for each country and year, to the original dataset (datapp)
id_demo=unique(datapp.countryyear);

cdid=[];
outid=[];
cdid_demogr=[];
cdindex=0;
for i=1:length(id_demo)
   if i==1
    napp_market_year=sum(strcmp(datapp.countryyear, id_demo(i)));
    cdid=[cdid ; i*ones(napp_market_year,1)];
    cdindex=[1 ; cdindex(end)+napp_market_year];
    vec=zeros(napp_market_year,1);
    vec(:,:)=outside{i,1};
    datapp.outsideshare(1:cdindex(end))=vec(:,:);
    clear vec
   else
    napp_market_year=sum(strcmp(datapp.countryyear, id_demo(i)));
    cdid=[cdid ; i*ones(napp_market_year,1)];
    cdindex=[cdindex ; cdindex(end)+napp_market_year];
    vec=zeros(napp_market_year,1);
    vec(:,:)=outside{i,1};
    datapp.outsideshare(cdindex(end-1)+1:cdindex(end))=vec(:,:);
    clear vec
   end
end
cdindex(1)=[];

%create dummy vars for nest and append them to the table
datapp.nest=removecats(datapp.nest,'OUTSIDE');
nest=dummyvar(datapp.nest);
nest_number=unique(datapp.nest);
datapp=[datapp array2table(nest)];
datapp.Properties.VariableNames(26:end) = string(nest_number);



disp(['Object cdid dimensions: ' num2str(size(cdid)) ])

%the vector below provides for each index the of the last observation in the data  

disp(['The dimensions of object cdindex are      ' num2str(size(cdindex)) ])

%scaling of price and all relevant characterisitics by 100
scaling=100;
datapp.price=datapp.price./scaling;
datapp.averagescore=datapp.averagescore./scaling;
datapp.iap=datapp.iap./scaling;
datapp.nofreviews=datapp.nofreviews./scaling;
datapp.multiplier=datapp.multiplier./scaling;
datapp.EDUCATION=datapp.EDUCATION./scaling;
datapp.ENTERTAINMENT=datapp.ENTERTAINMENT./scaling;
datapp.GAME1=datapp.GAME1./scaling;
datapp.GAME2=datapp.GAME2./scaling;
datapp.GAME3=datapp.GAME3./scaling;
datapp.PERSONALIZATION=datapp.PERSONALIZATION./scaling;
datapp.TOOLS=datapp.TOOLS./scaling;

%original setup: 

%characteristics of the products are price, average score,
%in-app-purchases, and the dummy varibales for genre (EDUCATION was dropped
%due to multicollinearity)
x1=[ones(size(datapp,1),1) table2array(datapp(:,{'price', 'averagescore', 'iap', 'ENTERTAINMENT', 'GAME1', 'GAME2', 'GAME3', 'PERSONALIZATION','TOOLS'}))];

%only price is allowed to interact with the demographic income
x2=[datapp.price];

%the IV is composed of as a Hausman Style instrument built as the average 
%price of the same app in all other countries, and the dummy varibales for 
%genre (EDUCATION was dropped due to multicollinearity)
IV = [datapp.avgprice table2array(datapp(:,{'price', 'averagescore', 'iap', 'ENTERTAINMENT', 'GAME1', 'GAME2', 'GAME3', 'PERSONALIZATION','TOOLS'}))];

%assign the marketshares to the vector s_jt
s_jt=datapp.mktshare;

%assign the marketshares of the outside good to the vector s_0
s_0=datapp.outsideshare;


disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                    ')

%starting values. zero elements in the following matrix correspond to
%coeff that will not be max over,i.e are fixed at zero. 

disp('                                                                    ')
disp(['The dimensions of object theta2w are      ' num2str(size(theta2w)) ])
disp('                                                                    ')

%create a vector of the non-zero elements in the above matrix, and the
%corresponding row and column indices. this facilitates passing values %
%to the functions below. %

[theti, thetj, theta2]=find(theta2w);


%number of markets = (# of years)*(# of countries)
nmkt = length(id_demo);
cdid_demogr=cdid;
vfull = v(cdid_demogr,:);
dfull = demogr(cdid_demogr,:);

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                   ')

n_inst = size(IV,2);   %Number of instruments for price

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                    ')

disp(['The dimensions of object IV are ' num2str(size(IV)) ])

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                    ')

%create weight matrix
invA = inv(IV'*IV);
mid2 = x1'*IV*invA*IV'*x1;
inv(mid2);

disp(['The dimensions of object invA  are ' num2str(size(invA)) ])

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                   ')

%% Estimation of BLP
%Logit results and save the mean utility as initial values for the
%search below.

y = log(s_jt) - log(s_0);

mid = x1'*IV*invA*IV';
t = (mid*x1)\(mid*y);
mvalold = x1*t;
oldt2 = zeros(size(theta2));
mvalold = exp(mvalold);

%s_jt and outshr and x1 are data that Nevo provides

disp(['Object y dimensions: ' num2str(size(y)) ])
disp(['Object mid dimensions: ' num2str(size(mid)) ])
disp(['Object t dimensions: ' num2str(size(t)) ])
disp(['Object mvalold dimensions: ' num2str(size(mvalold)) ])
disp(['Object oldt2 dimensions: ' num2str(size(oldt2)) ])

%the next command creates a new file, mvalold.mat, with mvaoldold and oldt2 
%in it, and then clears out the old mvalold from memory. 

save mvalold mvalold oldt2
clear mid y outshr t oldt2 mvalold temp sum1


disp(['Object vfull dimensions: ' num2str(size(vfull)) ])
disp(['Object dfull dimensions: ' num2str(size(dfull)) ])

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                   ')

%Below, set the maximum number of iterations for the main optimization 
%command. Note that the number of iterations for the meanval.m calculation 
%is separate, and unconstrained. 

options = optimset('GradObj','off','MaxIter',150,'Display','iter','TolFun',0.01,'TolX',0.01);
tic

%The following command computes the estimates using a simplex search method

[theta2,fval,exitflag,output]  = fminsearch('gmmobjg',theta2, options);

comp_t = toc/60;

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                   ')

theta2w = full(sparse(theti,thetj,theta2));

%computing the s.e.

vcov = var_cov_medicare(theta2);
se = sqrt(diag(vcov));
t = size(se,1) - size(theta2,1);
se2w = full(sparse(theti,thetj,se(t+1:size(se,1))));

%var_cov is a separate matlab file
disp(['Object vcov dimensions: ' num2str(size(vcov)) ])
disp(['Object se dimensions: ' num2str(size(se)) ])

disp(['Object theta2w dimensions:     ' num2str(size(theta2w)) ])
disp(['Object t dimensions:     ' num2str(size(t)) ])
disp(['Object se2w dimensions:     ' num2str(size(se2w)) ])

disp('                                                                    ')
disp('**********************************************************************')
disp('                                                                   ')

%histogram of the coefficients
alfa_i=[];
alfa_i2=[];

for i=1:nmkt
    data_market=reshape(demogr(i,1:ns*(length(theta2w)-1)),ns,(length(theta2w)-1));
    v_market=reshape(v(i,1:ns),ns,1); % caution: v is created to have 1000 columns
    alfa_i2=[alfa_i2 ; data_market*(theta2w(1,2:end)')+theta2w(1,1)*v_market(:,1)];
    alfa_i=[alfa_i ; data_market*(theta2w(1,2:end)')];
    
end
alfa_i=(theta1(2)+alfa_i2)/100;
index=find(alfa_i>0);
%alfa_i_counterfactual(index)=-alfa_i_counterfactual(index);
hist(alfa_i, 25)
title('Distribution of the price coefficient - 2007', 'FontSize', 14);
xlabel('Values', 'FontSize', 12)
ylabel('Frequency', 'FontSize', 12)
%xlim([-0.11 -0.08])
%compute the elasticities
%reshape the alfas
alfa_i_reshaped=reshape(alfa_i,ns,length(cdindex))';
alfa_i_reshaped=alfa_i_reshaped(cdid,:);
load mvalold
load gmmresid gmmresid
expmu = exp(mufunc(x2,theta2w));
f = ind_sh(mvalold,expmu);
unobservable_component=gmmresid;
mval=(x1*theta1);
f2 = sum((ind_sh(exp(mval+gmmresid),expmu))')/ns;
f2 = f2';
error=s_jt-f2;

save(['v2_IV_random_app_iteration_' num2str(istart) '.mat'])
input.data = [zeros(2,length([theta1;theta2']))];
input.data(1,1:length([theta1;theta2'])) = [theta1;theta2'];
input.data(2,1:length(se)) = [se];
latexTable(input)
disp(['The value of the objective function at the optimum:     ' num2str(fval)])



%% Unused code
% %define the colums containing the variables
% id_app=1; %id market plan
% id_market=2; %id market (country for each year)
% ms=3; %market shares
% price=4; %price
% developer=5; %developer name 
% average_score=6; %average score
% nofreviews=7; %number of reviews
% iap=8; %dummy for in-app purchases
% country=9; %country 
% year=10; %year
% nest=11; %nest of apps
% new_est=12; %estimated number of downloads
% multiplyier=13; %multiplyier
% 
% 
% 
% %create dummy vars for country and append them to the table
% countries=dummyvar(datapp.country); %create dummy vars for the countries
% country_names=unique(datapp.country); %extract unique country names
% datapp=[datapp array2table(countries)]; %add dummy cars to the data table
% datapp.Properties.VariableNames(20:end) = string(country_names); %rename dummy vars according to country name
% 
% %create dummy vars for nest and append them to the table
% datapp.nest=categorical(datapp.nest);
% nest=dummyvar(datapp.nest);
% nest_number=unique(datapp.nest);
% datapp=[datapp array2table(nest)];
% datapp.Properties.VariableNames(20:end) = string(nest_number);
% 
% 
