function [sh,sij,wsij]=ShareCalculation(theta,delta,data)

% ShareCalculation
% Calculates the predicted market share vectors for given parameters
% The code works both for Sparse Grid Integration (with a weight) 
% and Halton/Pseudo Monte Carlo Integration. If the option
% drawsintegretion=1 in the main file integration without weights is used.

% Written by Mathias Reynaert (2013)

if data.drawsintegration~=1

%% Unpack
nodes=data.nodes;
dummarket=data.dummarket;
xv=data.xv;
qweight=data.qweight;
nrc=data.nrc;
cdid=data.cdid;

%% Market Share
mu=zeros(size(xv,1),nodes);
for i=1:nrc
  mu=mu+xv(:,(i-1)*nodes+1:i*nodes).*theta(i,:);
end
mudel=kron(ones(1,nodes),delta)+mu;
numer1 = exp(mudel);
sumMS=(dummarket'*numer1);
denom1=1+sumMS(cdid,:);
sij=(numer1./denom1);
wsij=qweight.*sij;
sh=sum(qweight.*sij,2);

else
% Unpack
ndraws=data.ndraws;
dummarket=data.dummarket;
xv=data.xv;
nrc=data.nrc;
cdid=data.cdid;
j = data.j;    
%% Market Share
mu=zeros(size(xv,1),ndraws);
for i=1:nrc
    for k = 1:1+j
        mu=mu+xv(:,(i-1)*(1+j)*ndraws+(k-1)*ndraws+1:(i-1)*(1+j)*ndraws+k*ndraws).*theta((i-1)*(1+j)+k,:);
    end
end
mudel=kron(ones(1,ndraws),delta)+mu;
numer1 = exp(mudel);
sumMS=(dummarket'*numer1);
denom1=1+sumMS(cdid,:);
sij=numer1./denom1;
wsij=[];
sh=mean(sij,2);
    
end
end
