function [omega_matrix f] = mktsh_elasticities_lischoosers(prices, alfa_i_counterfactual_reshaped, w_lis, gamma,demogr_counterfactual,theta2w)
% This function computes the market share for each product
%
% Written by Aviv Nevo, May 1998.
global ns cdid x2 x1 theta1 cdid_demogr
load gmmresid gmmresid
x1_lis=x1;
x1_lis(:,2)=prices; %"discounted" lis prices
x1_lis(:,3)=zeros(size(x1_lis(:,3),1),1); %lis do not pay deductable
x1_lis(:,5)=ones(size(x1_lis(:,5),1),1); %all lis get coverage in gap
x2_lis=[prices x2(:,2)];

%calculate the mu and the deltha
expmu = exp(mufunc_counterfactual(x2_lis,theta2w,demogr_counterfactual,cdid_demogr));
mvalold1=exp(x1_lis*theta1+gmmresid);
f = ind_sh(mvalold1,expmu);

%omega_matrix=diag(prices./market_shares.* sum(alfa_i_reshaped.*ind_sh(mval,expmu).*(1-ind_sh(mval,expmu)),2))/ns;
%omega_matrix=diag(alfa_i_counterfactual*market_shares.*(1-market_shares).*(1-w_lis./(1+gamma)));
%these are the diagonal elements of omega matrix 
omega_matrix=NaN(size(alfa_i_counterfactual_reshaped));
for i=1:length(cdid)
    omega_matrix(i,i)=(sum(alfa_i_counterfactual_reshaped(i, :).*(f(i,:).*(1-f(i,:))).*(1-w_lis(i)./(1+gamma(i))))/ns);
    for ii=i+1:length(cdid)
        if cdid(i)==cdid(ii)
            
            omega_matrix(i,ii)=-sum(alfa_i_counterfactual_reshaped(i, :).*f(i,:).*f(ii,:).*(1-w_lis(i)./(1+gamma(i))))/ns;
            omega_matrix(ii,i)=-sum(alfa_i_counterfactual_reshaped(ii, :).*f(ii,:).*f(i,:).*(1-w_lis(ii)./(1+gamma(ii))))/ns;
            %omega_matrix(i,ii)=-alfa_i_counterfactual*market_shares(i,:)*market_shares(ii,:)*(1-w_lis(i)/(1+gamma(i)));
            %omega_matrix(ii,i)=-alfa_i_counterfactual*market_shares(i,:)*market_shares(ii,:)*(1-w_lis(ii)/(1+gamma(ii)));

        else
            omega_matrix(i,ii)=0;
        end
        
    end
end

%omega_matrix=omega_matrix;