clear 
clc

global theta2w mtol istart startvalues

mtol = 1e-12;
n = 5;
startvalues = [1, -1, 1, -0.5;
               1, -0.5, 0.5, -0.5;
               0.5, -1, 1, -1;
               1, -2, 2, -0.5;
               2, -1, 1, -2;];
           
for istart = 1:n
    theta2w = [startvalues(istart,1:2); startvalues(istart,3:4)];
    save trackstart theta2w mtol istart startvalues
    v2_x2_random_app;
end