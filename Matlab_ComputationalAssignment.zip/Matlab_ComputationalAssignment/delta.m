function f = delta(theta,data)

% delta
% Contraction Mapping to find the mean utilities
% Written by Mathias Reynaert (2013)
% Original Source: Aviv Nevo (2000)
global mtol
load mvaloldoptiv
k=100;
i = 0;
if max(isnan(delta0)) == 1
deltastart=zeros(data.nobs,1);
else
    deltastart=delta0;
end

% Unpack
logobsshare=data.logobsshare;

while k > mtol 
      % Market Share
      [sh, ~]=ShareCalculation(theta,deltastart,data);
      
      % Contraction Mapping
      delta1 = deltastart+logobsshare-log(sh);
             if max(isnan(delta1))==1
                disp('No Convergence - delta calculation failed: OVERFLOW')
                break
             end
      i = i + 1;
             if i>2500
                %disp('No Convergence - delta convergence failed')
                break
             end
      k=max(abs(delta1-deltastart));
      deltastart = delta1;
end

disp(['# of iterations for delta convergence:  ' num2str(i)])

delta0 = delta1;
save mvaloldoptiv.mat delta0

f=delta1;